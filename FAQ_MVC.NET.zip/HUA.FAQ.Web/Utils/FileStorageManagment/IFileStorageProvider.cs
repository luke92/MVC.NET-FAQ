﻿namespace HUA.FAQ.Web.Utils.FileStorageManagment
{
    public interface IFileStorageProvider
    {
        void RemoveFile(string folder, string fileName);
        void SaveFile(string folder, string fileName, byte[] file);
        byte[] GetFile(string folder, string fileName);
    }

    
}