﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HUA.FAQ.Entities.Migrations
{
    class Configuration : DbMigrationsConfiguration<HUA.FAQ.Entities.FaqContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
        }

        protected override void Seed(HUA.FAQ.Entities.FaqContext context)
        {
            if (!context.Tipos.Any())
            {
                #region Tipos

                List<Tipo> tipos = new List<Tipo>();

                tipos.Add(new Tipo()
                {
                    TipoID = Guid.NewGuid(),
                    Nombre = "Pediatria"
                });

                tipos.Add(new Tipo()
                {
                    TipoID = Guid.NewGuid(),
                    Nombre = "Adulto"
                });

                tipos.Add(new Tipo()
                {
                    TipoID = Guid.NewGuid(),
                    Nombre = "Embarazo"
                });

                tipos.Add(new Tipo()
                {
                    TipoID = Guid.NewGuid(),
                    Nombre = "Cancer"
                });

                tipos.Add(new Tipo()
                {
                    TipoID = Guid.NewGuid(),
                    Nombre = "Ambulatorio"
                });

                tipos.Add(new Tipo()
                {
                    TipoID = Guid.NewGuid(),
                    Nombre = "Terminal"
                });

                context.Tipos.AddRange(tipos);

                base.Seed(context);

                #endregion
            

                #region Tags

                List<Tag> tags = new List<Tag>();

                tags.Add(new Tag()
                {
                    TagID = Guid.NewGuid(),
                    Nombre = "¿Qué hacer?",
                });

                tags.Add(new Tag()
                {
                    TagID = Guid.NewGuid(),
                    Nombre = "Erupciones",
                });

                tags.Add(new Tag()
                {
                    TagID = Guid.NewGuid(),
                    Nombre = "Gripe",
                });

                tags.Add(new Tag()
                {
                    TagID = Guid.NewGuid(),
                    Nombre = "Mocosidad",
                });

                tags.Add(new Tag()
                {
                    TagID = Guid.NewGuid(),
                    Nombre = "Tos",
                });

                tags.Add(new Tag()
                {
                    TagID = Guid.NewGuid(),
                    Nombre = "Fiebre",
                });

                tags.Add(new Tag()
                {
                    TagID = Guid.NewGuid(),
                    Nombre = "Escalofrios",
                });

                context.Tags.AddRange(tags);

                base.Seed(context);

                #endregion
            
                #region FAQ

                List<FAQ> faqs = new List<FAQ>();

                Tipo tipo = tipos.FirstOrDefault();
                faqs.Add(new FAQ()
                {
                    FAQID = Guid.NewGuid(),
                    Tipo = tipo,
                    Nombre = "¿Qué hacer en caso de gripe?",
                    Descripcion = "Ayuda simple para el tratamiento de la gripe",
                    Solucion = "En caso de presentar fiebre, se recomienda consumir Ibuprofeno cada 8hs por 5 días.",
                    Tags = tags,
                    Rating = 0,
                    CantidadVotos = 0
                });

                faqs.Add(new FAQ()
                {
                    FAQID = Guid.NewGuid(),
                    Tipo = tipo,
                    Nombre = "¿Cómo saber si tengo gripe A?",
                    Descripcion = "Diagnóstico simple para la detección temprana de la gripe A",
                    Solucion = "Este análisis clínico de La Detección de la Gripe A del subtipo H1N1 mediante técnica de reacción en cadena de la polimerasa detecta el virus de gripe de origen porcina en las secreción(muestras de líquido) de la nariz, boca, y garganta.La gripe de origen porcina también se conoce como influenza porcina o virus H1N1.Este examen se usa para diagnosticar la gripe porcina.",
                    Tags = tags,
                    Rating = 0,
                    CantidadVotos = 0
                });

                faqs.Add(new FAQ()
                {
                    FAQID = Guid.NewGuid(),
                    Tipo = tipo,
                    Nombre = "Primeros sintomas del resfrío",
                    Descripcion = "Enterate de cuales son los sintomas más comunes del resfrío",
                    Solucion = "El resfriado común en la mayoría de los casos causa rinorrea o secreción nasal, congestión nasal y estornudo. Asimismo, es posible que se presente dolor de garganta, tos, dolor de cabeza u otros síntomas.",
                    Tags = tags,
                    Rating = 0,
                    CantidadVotos = 0
                });

                context.Faqs.AddRange(faqs);

                base.Seed(context);

                #endregion

                context.Database.ExecuteSqlCommand("CREATE PROCEDURE obtenerFAQsRelacionadasPorTagID  @ID uniqueidentifier AS BEGIN SELECT * FROM TagFAQs as t INNER JOIN Faqs as f ON f.FAQID = t.FAQ_FAQID WHERE t.Tag_TagID = @ID; END");

            }
        }
    }
}
