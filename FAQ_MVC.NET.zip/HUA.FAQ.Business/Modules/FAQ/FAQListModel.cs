﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HUA.FAQ.Business.Modules.FAQ
{
    public class FAQListModel
    {
        public List<FAQModel> Items { get; set; }

        public FAQListModel(List<FAQModel> listaFaqModels)
        {
            Items = new List<FAQModel>();
            Items.AddRange(listaFaqModels);
        }

        public FAQListModel()
        {
            Items = new List<FAQModel>();
        }
    }
}
