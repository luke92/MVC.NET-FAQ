﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using HUA.FAQ.Business.Modules.FAQ.User;
using HUA.FAQ.Entities;

namespace HUA.FAQ.Business.Modules.FAQ
{
    public class LoginModule
    {
        public static Entities.User ToEntity(LoginModel userModel)
        {
            return new Entities.User()
            {
                UserID = userModel.Id,
                UserName = userModel.UserName,
                Password = userModel.Password
            };
        }

        public static LoginModel ToModel(Entities.User user)
        {
            return new LoginModel()
            {
                Id = user.UserID,
                UserName = user.Nombre,
                Password =  user.Password
            };
        }

        public static LoginModel Get(Guid ID)
        {
            if (ID == null) return null;
            var db = new FaqContext();
            return ToModel(db.Users.Find(ID));
        }

        public static int Add(FaqContext db, LoginModel userModel)
        {
            db.Users.Add(ToEntity(userModel));
            return db.SaveChanges();
        }

        public static int Add(LoginModel userModel)
        {
            userModel.Id = Guid.NewGuid();
            return Add(new FaqContext(), userModel);
        }

        public static bool ExistModel(LoginModel userModel)
        {
            var db = new FaqContext();
            return db.Users.Any(t => t.UserName.ToLower().Equals(userModel.UserName.ToLower()));
        }

        public static bool ExistUser(LoginModel userModel)
        {
            var db = new FaqContext();
            return db.Users.Any(t => t.UserName.ToLower().Equals(userModel.UserName.ToLower()) 
                                     && t.Password.ToLower().Equals(userModel.Password));
        }
    }
}
