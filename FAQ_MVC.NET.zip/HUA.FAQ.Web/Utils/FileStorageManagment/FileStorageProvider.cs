﻿using System.IO;

namespace HUA.FAQ.Web.Utils.FileStorageManagment
{
    public class FileStorageProvider : IFileStorageProvider
    {
        private readonly string RootPath;

        public FileStorageProvider(string repositoryRootPath)
        {
            RootPath = System.Web.Hosting.HostingEnvironment.MapPath(repositoryRootPath); //repositoryRootPath;
        }

        #region Private methods
        private string GetFileFolderPath(string folder)
        {
            return string.Format(@"{0}\{1}", RootPath, folder);
        }
        #endregion Private Methods

        #region Public Methods
        public void SaveFile(string folder, string fileName, byte[] file)
        {
            string path = GetFileFolderPath(folder);

            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);

            string filePath = Path.Combine(path, fileName);

            File.WriteAllBytes(filePath, file);
        }

        public byte[] GetFile(string folder, string fileName)
        {
            string path = GetFileFolderPath(folder);

            string filePath = Path.Combine(path, fileName);

            return File.ReadAllBytes(filePath);
        }

        public void RemoveFile(string folder, string fileName)
        {
            string path = GetFileFolderPath(folder);

            string filePath = Path.Combine(path, fileName);

            if (File.Exists(filePath))
                File.Delete(filePath);
        }
        #endregion Public Methods
    }
}