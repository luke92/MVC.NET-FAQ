﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HUA.FAQ.Data
{
    class Tag
    {
        public Guid TagID { get; set; }

        public string Nombre { get; set; }
    }
}
