﻿ListaPanel = function (obj) {
    var mainDiv = $(obj.mainDiv);
    var triState = obj.triState != null ? obj.triState : false;
    var titleParseText = obj.parseText;
    this.dialog = obj.dialog != null ? obj.dialog : true;
    var functionalityToAdd = obj.functionalityToAdd;
    var index = ListaPanelController.AddListaPanel(this);
    this.index = index;
    this.title = obj.title != null ? obj.title : "";
    this.listName = mainDiv.attr("id").substring(0, mainDiv.attr("id").indexOf("maindiv"));
    var listName = this.listName;
    var mainDivs = [];
    var mainDivsLabels = [];
    this.attributes = [];
    var attrs = this.attributes;
    var regex = new RegExp("([A-Z]*[a-z]*)*maindiv");
    $.each(mainDiv.find("div"),
        function (i, elem) {
            if (regex.test(elem.id)) {
                mainDivs.push(elem);
                var mainDivIndex = elem.id.indexOf("maindiv");
                var attr = elem.id.substring(0, mainDivIndex);
                var elemAsJquery = $(elem);
                elemAsJquery.show();
                var hidden = false;
                if (elemAsJquery.parent()
                    .hasClass("invisible")) hidden = true;
                if (elemAsJquery.find("input, textarea").attr("id") != null &&
                    elemAsJquery.find("input, textarea").attr("id").indexOf("_Value") >= 0) {
                    attrs.push({
                        attrName: attr,
                        inputId: elemAsJquery.find("input, textarea").attr("id"),
                        selectId: elemAsJquery.find("select").attr("id"),
                        hidden: hidden
                    });

                } else if (elemAsJquery.find("input, textarea").attr("id") == null) {
                } else {

                    attrs.push({
                        attrName: attr,
                        inputId: elemAsJquery.find("input, textarea").attr("id"),
                        selectId: null,
                        hidden: hidden
                    });
                }
            }
        });

   

    $.each(mainDiv.find("div.editor-label label"),
        function (i, elem) {
            mainDivsLabels.push(elem);
        });
    var mainDivsWithLabels = [];
    for (var i = 0; i < mainDivs.length; i++) {
        var newDiv = document.createElement("div");
        newDiv.appendChild(mainDivsLabels[i]);
        newDiv.appendChild(mainDivs[i]);
        mainDivsWithLabels.push(newDiv);
    }
   

    // Private functions
    var groupedElements = [[]];
    this.findListaPanelSaved = function (mainDivsWithLabels) {
        $(mainDivsWithLabels)
            .each(function (index, element) {
                var elementId;
                if ($(element).children().first().next().children().first().attr("class") !== "combodate") {
                    elementId = $(element).children().first().next().children().first().attr("id");
                } else {
                    elementId = $(element).children().first().next().children().first().next().attr("id");
                }
                var elementIndex = elementId[elementId.indexOf("__") - 1];
                if (groupedElements[elementIndex] == undefined) groupedElements.push([]);
                groupedElements[elementIndex].push(element);
            });
    }

    this.removeUnnecesaryParentAttributes = function () {
        this.findListaPanelSaved(mainDivsWithLabels);
        for (x = 0; x < mainDivsWithLabels.length; x++) {
            var elementId = "";
            if ($(mainDivsWithLabels[x]).children().first().next().children().first().attr("class") !== "combodate") {
                elementId = $(mainDivsWithLabels[x]).children().first().next().children().first().attr("id");
            } else {
                elementId = $(mainDivsWithLabels[x]).children().first().next().children().first().next().attr("id");
            }
            if (elementId.indexOf("_0__") === -1) {
                mainDivsWithLabels.splice(x, 1);
                this.attributes.splice(x, 1);
                x--;
            }
        };
    }


    this.fixDatepickers = function (elem) {
        elem.find('.fechames')
            .removeClass('hasDatepicker')
            .datepicker({
                changeMonth: true,
                changeYear: true,
                changeDate: false,
                dateFormat: 'MM yy',
                startView: "months",
                minViewMode: "months",
                beforeShow: function (input) {
                    $(input).datepicker("widget").addClass('hide-month hide-current hide-calendar');
                },
                onClose: function (dateText, inst) {
                    $(this).datepicker('setDate', new Date(inst.selectedYear, inst.selectedMonth, 1));
                }
            });
        if (elem.find('.fechames').length) {
            setMothYearDateStyle();
        }


        elem.find('.fecha')
            .removeClass('hasDatepicker')
            .datepicker({
                changeMonth: true,
                changeYear: true
            });
        elem.find('.tiempo')
            .removeClass('hasDatepicker')
            .timepicker({
                changeMonth: true,
                changeYear: true
            });
        elem.find('.fechatiempo')
            .removeClass('hasDatepicker')
            .datetimepicker({
                changeMonth: true,
                changeYear: true
            });
    }


    

    //this.findListaPanelSaved = function (elements) {
    //    $(elements)
    //        .each(function (index, element) {
    //            var elementIndex = element.inputId[element.inputId.indexOf("__") - 1];
    //            if (groupedElements[elementIndex] == undefined) groupedElements.push([]);
    //            groupedElements[elementIndex].push(element);
    //        });
    //}

 
    this.addListaPanelItem = function () {
        this.removeUnnecesaryParentAttributes();
        var newItem = new ListaPanelItem(mainDivsWithLabels, this, titleParseText, this.title);
        var html = newItem.generateHtml();
        var newDiv = document.createElement("div");
        newDiv.innerHTML = html;
        $("#lista-panel-" + this.index).find("div[name=lista-panel-items]").append(html);
        //        this.fixDatepickers($("#lista-panel-" + this.index).find("div[name=lista-panel-items]"));
        html = $(html);
        //        console.log($("#lista-panel-" + this.index).find("#lista-panel-" + this.index + "-item-" + newItem.index));
        $("#lista-panel-" + this.index)
            .find("#lista-panel-" + this.index + "-item-" + newItem.index)
            .find("div[name=header-container]")
            .hide();
        if (this.dialog && newItem.index > 0) {
            newItem.dialog();
        }
        functionalityToAdd != null ? functionalityToAdd() : null;

    };

    this.setTitleParseText = function (text) {
        titleParseText = text;
    }

    var listaPanel = document.createElement("div");
    mainDiv.html(listaPanel);
    listaPanel.name = "lista-panel";
    listaPanel = $(listaPanel);
    listaPanel.append("<div name='lista-panel' id='lista-panel-" + index + "'>");
    var listaPanelItems = $(document.createElement("div"));
    listaPanel.children().first().append(listaPanelItems);
    listaPanelItems.attr("name", "lista-panel-items");


    var addButtonContainer = $(document.createElement("div"));
    listaPanel.children().first().append(addButtonContainer);
    addButtonContainer.attr("name", "add-btn-container").addClass("add-btn-container");
    var addButton = document.createElement("button");
    addButton
        .innerHTML = "<i name='add-btn' class='fa fa-plus v-e-d-btns' onclick='ListaPanelController.Add(event, " +
        index +
        ")'>&nbsp;<span>Agregar</span></i>";
    addButton = $(addButton.innerHTML);
    addButtonContainer.append(addButton);


    ListaPanelController.Add(null, index);
    listaPanel.find("#lista-panel-" + index + "-item-0").hide();


    this.addElements = function (divMatrix) {
        for (i = 1; i < divMatrix.length; i++) {
                var newItem = new ListaPanelItem(divMatrix[0], this, titleParseText, this.title);
                var html = newItem.generateHtml();
                var newDiv = document.createElement("div");
                $("#lista-panel-" + this.index).find("div[name=lista-panel-items]").append(html);
                newDiv.innerHTML = html;

                //        this.fixDatepickers($("#lista-panel-" + this.index).find("div[name=lista-panel-items]"));
                html = $(html);
                //        console.log($("#lista-panel-" + this.index).find("#lista-panel-" + this.index + "-item-" + newItem.index));
                $("#lista-panel-" + this.index)
                    .find("#lista-panel-" + this.index + "-item-" + newItem.index)
                    .find("div[name=header-container]")
                    .hide();
                if (this.dialog && newItem.index > 0) {
                    newItem.dialog();
                }
                divMatrix[i].forEach(function (div, index) {
                    $(div).find("input").add($(div).find("textarea")).each(function (index, input) {
                        $(".ui-dialog " + "#" + input.id + "-form").val($(input).val());
                        $(".ui-dialog " + "#" + input.id + "-form").attr("name", "");
                    });
                });
                functionalityToAdd != null ? functionalityToAdd() : null;
                ListaPanelController.Save(null, newItem.index, this.index);

            };
        }

    this.addElements(groupedElements);

}

ListaPanelItem = function (mainDivsWithLabels, parent, titleParseText, title) {
    this.index = ListaPanelController.AddListaPanelItem(this, parent.index);
    this.listaPanelItem = $();
    this.headerContainer = $();
    this.formContainer = $();
    this.formFieldsContainer = $();
    this.modelFormFieldsContainer = $();
    this.buttonsContainer = $();
    this.openDialog = null;
    this.title = title;


    this.id = "lista-panel-" + parent.index + "-item-" + this.index;

    this.viewing = false;
    this.editing = false;

    this.parseText = function () {
        var text = titleParseText;
        for (var i = 0; i < parent.attributes.length; i++) {
            var attr = parent.attributes[i].attrName;
            var inputElem, selectElem;
            if (parent.attributes[i].selectId == null) {
                inputElem = $(".ui-dialog " +"#" + parent.attributes[i].inputId.replace("_0__", "_" + this.index + "__") + "-form");

                text = text.replace("[" + attr + "]", inputElem.val());
            } else {
                selectElem = $("#" + parent.attributes[i].selectId.replace("_0__", "_" + this.index + "__") + "-form");
                text = text.replace("[" + attr + "]", selectElem.find("option:selected").text());
            }

        }
        return text;
    }

    this.setModelFormFields = function () {
        var formFields = this.openDialog != null ? this.openDialog : $("#" + this.id);
        // ;
        $.each(formFields.find("div[name=model-form-fields-container]").find("input, select, textarea"),
            function (index, elem) {
                var element = $(elem);
                if (element.attr("id") != null) {// TODO be very careful with this, perhaps I should be grabbing some elem with no id?
                    if (element.attr("id") != null && element.attr("id").indexOf("_Id") >= 0) {
                        var valueAttrId = element.attr("id").replace("_Id", "_Value");
                    }
                   
                    element.val($("#" + element.attr("id") + "-form").val());
                }
            });
    }

    this.setFormFields = function () {
        var formFields = this.openDialog != null ? this.openDialog : $("#" + this.id);
        // ;
        $.each(formFields.find("div[name=form-fields-container]").find("input, select, textarea"),
            function (index, elem) {
                var element = $(elem);
                if (element.attr("id") != undefined) {
                    element.val($("#" + element.attr("id").replace("-form", "")).val());
                }
            });
    }

    this.updateTitleText = function () {
        $("#" + this.id).find("label[name=title-text]").text(this.parseText());
    };

    this.save = function () {
        this.updateTitleText();
        this.setModelFormFields();
        var formFields = this.openDialog != null ? this.openDialog : $("#" + this.id);
        formFields.find("div[name=form-container]").fadeOut();
        $("#" + this.id).find("div[name=header-container]").fadeIn();
        this.editing = false;
        if (this.openDialog != null) {
            //;
            var div = $(this.openDialog.dialog("destroy"));
            var listItemDiv = $("#" + this.id);
            var headerContainer = listItemDiv.find("div[name=header-container]");
            headerContainer.after(div);
        }
    }

    this.remove = function () {
        //        console.log(this.listaPanelItem);
        //if (confirm("Está seguro que desea remover este elemento?")) {
        $("#" + this.id)
            .fadeOut(function () {
                $(this).remove();
            });
        if (this.openDialog != null) {
            this.openDialog.dialog("destroy");
        }
        //}
    };

    this.cancel = function () {
        if (!this.editing && !this.viewing) this.remove();
        else {
            $("#" + this.id).find("div[name=form-container]").fadeOut();
            this.setFormFields();
            if (this.openDialog != null) {
                var div = $(this.openDialog.dialog("destroy"));
                $("#" + this.id).find("div[name=header-container]").after(div.wrap("div[name=form-container]"));
            }
        }
        this.editing = false;
        this.viewing = false;
    };

    this.edit = function () {
        this.editing = true;
        this.viewing = false;
        this.setFormFields();
        var formFields = /*this.openDialog != null ? this.openDialog : */$("#" + this.id);
        formFields.find("div[name=form-fields-container]").fadeIn();
        formFields.find("div[name=form-fields-container]").find("input, select, textarea").attr("disabled", false);
        formFields.find("div[name=buttons-container]").fadeIn();

        if (this.openDialog != null) {
            this.dialog();
        }
        formFields.find("div[name=form-container]").fadeIn();

    }

    this.view = function () {
        this.viewing = true;
        this.setFormFields();
        var formFields = this.openDialog != null ? this.openDialog : $("#" + this.id);
        formFields.find("div[name=form-fields-container]").find("input, select, textarea").attr("disabled", true);
        formFields.find("div[name=buttons-container]").fadeOut();
        if (this.editing) {
            if (this.openDialog != null) this.openDialog.dialog("open");
            formFields.find("div[name=form-container]").fadeIn();
        } else {
            if (this.openDialog != null) {
                this.dialog();
            }
            formFields.find("div[name=form-container]").fadeToggle();
        }

        this.editing = false;
    }
    
   

    this.generateHtml = function () {
        this.headerContainer = $(document.createElement("div"));
        this.headerContainer.attr("name", "header-container");
        if (parent.triState) {
            // this is where we would have to add the tri state button code
            this.headerContainer.append("<div style='width:20%;'></div>");
            this.headerContainer.append("<div style='width:50%';><label name='title-text'></label></div>");
        } else {
            this.headerContainer
                .append("<div style='width:50%;display:inline-flex;' name='title-div' class='title-div'><label name='title-text'></label></div>");
        }
        this.headerContainer
            .append("<div style='width:30%;display:inline-flex;' name='manage-btns-div' class='manage-btns-div'>" +
                "<i name='view-btn' class='fa fa-eye fa-2x v-e-d-btns' onclick='ListaPanelController.View(event, " +
                this.index +
                "," +
                parent.index +
                ")'></i>" +
                "<i name='edit-btn' class='fa fa-pencil-square-o fa-2x v-e-d-btns' onclick='ListaPanelController.Edit(event, " +
                this.index +
                "," +
                parent.index +
                ")'></i>" +
                "<i name='delete-btn' class='fa fa-trash-o fa-2x v-e-d-btns' onclick='ListaPanelController.Remove(event, " +
                this.index +
                "," +
                parent.index +
                ")'></i>" +
                "</div>");

        this.formContainer = $(document.createElement("div")).attr("name", "form-container");

        this.formFieldsContainer = $(document.createElement("div")).attr("name", "form-fields-container");
        this.modelFormFieldsContainer = $(document.createElement("div")).attr("name", "model-form-fields-container");
        for (var input in mainDivsWithLabels) {
            if (mainDivsWithLabels.hasOwnProperty(input)) {
                this.formFieldsContainer.append(mainDivsWithLabels[input].cloneNode(true));
                this.modelFormFieldsContainer.append(mainDivsWithLabels[input].cloneNode(true));

            }
        }
        $.each(this.formFieldsContainer.find("input, select, textarea"),
            function (index, elem) {
                var element = $(elem);
                element.attr("id", element.attr("id") + "-form");
                element.attr("name", "");
            });
        this.modelFormFieldsContainer.hide();

        this.buttonsContainer = $(document.createElement("div"))
            .attr("name", "buttons-container")
            .addClass("lista-panel-form-button-container");

        this.buttonsContainer
            .append("<button name='save-btn' class='btn btn-primary' onclick='ListaPanelController.Save(event, " +
                this.index +
                "," +
                parent.index +
                ")'>Guardar</button><button name='cancel-btn' class='btn btn-default' onclick = 'ListaPanelController.Cancel(event, " +
                this.index +
                "," +
                parent.index +
                ")'>Cancelar</button>");

        this.formContainer.append(this.formFieldsContainer);
        this.formContainer.append(this.modelFormFieldsContainer);
        this.formContainer.append(this.buttonsContainer);
        //        this.formContainer.hide();

        this.listaPanelItem = $(document.createElement("div"))
            .attr("name", "lista-panel-item")
            .attr("id", this.id)
            .addClass("lista-panel-item");
        this.listaPanelItem.append($(document.createElement("div"))
            .attr("name", "lista-panel-item")
            .attr("id", this.id)
            .addClass("lista-panel-item"));
        this.listaPanelItem.children().first().append(this.headerContainer);
        this.listaPanelItem.children().first().append(this.formContainer);
        this.modelFormFieldsContainer
            .append("<input name='" + parent.listName + ".Index' value='" + this.index + "'/>")
            .append("<input data-val='true' data-val-required='El campo Id es obligatorio.' id='" +
                parent.listName +
                "_" +
                this.index +
                "__Id' name='" +
                parent.listName +
                "[" +
                this.index +
                "].Id' type='hidden' value='" +
                guid() +
                "'" +
                "style='display:inline-block;'/>");
        for (var i = 0; i < parent.attributes.length; i++) {
            var elem = parent.attributes[i];

            var element = this.formFieldsContainer.find("#" + elem.inputId + "-form");
            var elementModel = this.modelFormFieldsContainer.find("#" + elem.inputId);

            if (elem.hidden) {
                element.parent().parent().css("display", "none");
            }
            //            console.log(elem);
            var oldId = element.attr("id");
            var newId = oldId.replace("_0__" + elem.attrName,
                "_" + this.index + "__" + elem.attrName);
            element.attr("id", newId);

            var oldIdModel = elementModel.attr("id");
            var newIdModel = oldIdModel.replace("_0__" + elem.attrName,
                "_" + this.index + "__" + elem.attrName);
            elementModel.attr("id", newIdModel);

            var oldNameModel =
                elementModel.attr("name");
            var newNameModel = oldNameModel.replace("[0]." + elem.attrName, "[" + this.index + "]." + elem.attrName);
            elementModel.attr("name", newNameModel);
            elementModel.parent()
                .children("span")
                .attr("data-valmsg-for",
                    elementModel.parent()
                    .children("span")
                    .attr("data-valmsg-for")
                    .replace("[0]." + elem.attrName, "[" + this.index + "]." + elem.attrName));


            var oldName =
                element.attr("name");
            var newName = oldName.replace("[0]." + elem.attrName, "[" + this.index + "]." + elem.attrName);
            element.attr("name", newName);
            element.parent()
                .children("span")
                .attr("data-valmsg-for",
                    element.parent()
                    .children("span")
                    .attr("data-valmsg-for")
                    .replace("[0]." + elem.attrName, "[" + this.index + "]." + elem.attrName));
            if (elem.selectId != null) {
                var selectElement = this.formFieldsContainer.find("#" + elem.selectId + "-form");
                var selectElementModel = this.modelFormFieldsContainer.find("#" + elem.selectId);

                var oldIdSelect = selectElement.attr("id");
                var newIdSelect = oldIdSelect.replace("_0__" + elem.attrName,
                    "_" + this.index + "__" + elem.attrName);
                selectElement.attr("id", newIdSelect);

                var oldIdSelectModel = selectElementModel.attr("id");
                var newIdSelectModel = oldIdSelectModel.replace("_0__" + elem.attrName,
                    "_" + this.index + "__" + elem.attrName);
                selectElementModel.attr("id", newIdSelectModel);


                var oldNameSelect =
                    selectElement.attr("name");
                var newNameSelect = oldNameSelect.replace("[0]." + elem.attrName,
                    "[" + this.index + "]." + elem.attrName);
                selectElement.attr("name", newNameSelect);

                var oldNameSelectModel =
                    selectElementModel.attr("name");
                var newNameSelectModel = oldNameSelectModel
                    .replace("[0]." + elem.attrName, "[" + this.index + "]." + elem.attrName);
                selectElementModel.attr("name", newNameSelectModel);
            }
        };

        return this.listaPanelItem.html();
    }
    var index = this.index;
    this.dialog = function (viewing) {
        
        this.openDialog = $("#" + this.id)
            .find("div[name=form-container]")
            .attr("title", this.title);

        this.openDialog = $("#" + this.id)
            .find("div[name=form-container]")
            .dialog({
                modal: true,
                close: function (event, ui) {
                    //                    console.log("Index: " + index);
                    //                    console.log("Parent index: " + parent.index);
                    ListaPanelController.Cancel(null, index, parent.index);
                    $("div[name=form-container]").last().remove();
                },
                width: 600
            });
        //        console.log("Instance: ");
        //        console.log(this.openDialog.dialog("instance"));
        this.openDialog.find("div[name=form-fields-container]")
            .find("input, select, textarea")
            .keyup(function (event) {
                if (event.keyCode === 13) {
                    $(this).closest("div[name=form-container]").find("button[name=save-btn]").click();
                } else if (event.keyCode === 27) {
                    $(this).closest("div[name=form-container]").find("button[name=cancel-btn]").click();
                }
            });

    }
}

ListaPanelController = {
    ListaPanelItems: [],
    ListaPanels: [],
    ListaPanelsCounter: 0,
    AddListaPanelItem: function (item, listaPanelIndex) {
        if (this.ListaPanelItems[listaPanelIndex] == null) {
            this.ListaPanelItems[listaPanelIndex] = {
                counter: 0,
                items: []
            };
        }
        this.ListaPanelItems[listaPanelIndex].items.push(item);
        this.ListaPanelItems[listaPanelIndex].counter++;
        return this.ListaPanelItems[listaPanelIndex].counter - 1;
    },
    AddListaPanel: function (listaPanel) {
        this.ListaPanels.push(listaPanel);
        this.ListaPanelsCounter++;
        return this.ListaPanelsCounter - 1;
    },
    RemoveListaPanelItem: function (index, parentIndex) {
        var listaPanelItem = this.ListaPanelItems[parentIndex];
        if (listaPanelItem != null && listaPanelItem.items[index] != null) this.ListaPanelItems[index] = null;
    },
    View: function (event, index, parentIndex) {
        if (event != null)
            typeof event.preventDefault !== "undefined" ? event.preventDefault() : (event.returnValue = false);
        var listaPanelItem = this.ListaPanelItems[parentIndex];
        if (listaPanelItem != null && listaPanelItem.items[index] != null) listaPanelItem.items[index].view();
    },
    Edit: function (event, index, parentIndex) {
        if (event != null)
            typeof event.preventDefault !== "undefined" ? event.preventDefault() : (event.returnValue = false);
        var listaPanelItem = this.ListaPanelItems[parentIndex];
        if (listaPanelItem != null && listaPanelItem.items[index] != null) listaPanelItem.items[index].edit();
    },
    Remove: function (event, index, parentIndex) {
        if (event != null)
            typeof event.preventDefault !== "undefined" ? event.preventDefault() : (event.returnValue = false);
        var listaPanelItem = this.ListaPanelItems[parentIndex];
        if (listaPanelItem != null && listaPanelItem.items[index] != null) {
            listaPanelItem.items[index].remove();
            this.RemoveListaPanelItem(index);
        }
    },
    Save: function (event, index, parentIndex) {
        if (event != null)
            typeof event.preventDefault !== "undefined" ? event.preventDefault() : (event.returnValue = false);
        var listaPanelItem = this.ListaPanelItems[parentIndex];
        if (listaPanelItem != null && listaPanelItem.items[index] != null) listaPanelItem.items[index].save();
    },
    Cancel: function (event, index, parentIndex) {
        if (event != null)
            typeof event.preventDefault !== "undefined" ? event.preventDefault() : (event.returnValue = false);
        var listaPanelItem = this.ListaPanelItems[parentIndex];
        if (listaPanelItem != null && listaPanelItem.items[index] != null) listaPanelItem.items[index].cancel();
    },
     Add: function (event, index) {
        if (event != null)
            typeof event.preventDefault !== "undefined" ? event.preventDefault() : (event.returnValue = false);
        var listaPanel = this.ListaPanels[index];
        listaPanel.addListaPanelItem();

    }
}

function guid() {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }

    return s4() +
        s4() +
        '-' +
        s4() +
        '-' +
        s4() +
        '-' +
        s4() +
        '-' +
        s4() +
        s4() +
        s4();
}