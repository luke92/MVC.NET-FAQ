﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using HUA.FAQ.Business.Modules.FAQ;
using HUA.FAQ.Business.Modules.FAQ.Tag;
using HUA.FAQ.Business.Modules.FAQ.Tipo;
using HUA.FAQ.Entities;

namespace HUA.FAQ.Business.Modules
{
    public class FAQModule : IModule<Entities.FAQ,FAQModel, FAQSearchModel>
    {
        private readonly IFaqContext context;
        public TagModule tagModule;
        public TipoModule tipoModule;
        public FAQModule(IFaqContext _context)
        {
            context = _context;
            tagModule = new TagModule(_context);
            tipoModule = new TipoModule(_context);
        }

        public Entities.FAQ ToEntity(FAQModel faqModel)
        {
            return new Entities.FAQ()
            {
                FAQID = faqModel.Id,
                //Tipo = TipoModule.ToEntity(faqModel.Tipo),
                TipoId = faqModel.TipoId,
                Tags = tagModule.ToEntities(faqModel.Tags),
                Solucion = faqModel.Solucion.Trim(),
                Descripcion = faqModel.Descripcion,
                Nombre = faqModel.Nombre.Trim(),
                Rating = faqModel.Rating,
                CantidadVotos = faqModel.CantidadVotos
            };
        }

        public FAQModel ToModel(Entities.FAQ entity)
        {
            return new FAQModel()
            {
                Id = entity.FAQID,
                TipoId = entity.Tipo.TipoID,
                Tipo = tipoModule.ToModel(entity.Tipo),
                Tags = tagModule.ToModels(entity.Tags),
                Solucion = entity.Solucion,
                Descripcion = entity.Descripcion,
                Nombre = entity.Nombre,
                Rating = entity.Rating,
                CantidadVotos = entity.CantidadVotos,

                TagsId = entity.Tags.Select(x => x.TagID).ToArray()
            };
        }

        public string[] GetSugerencias(string searchText)
        {
            return context.Faqs.Where(x => x.Nombre.ToLower().Contains(searchText.ToLower()))
                .Take(4).Select(x => x.Nombre).ToArray();
        }

        public FAQModel GetById(Guid ID)
        {
            if (ID == Guid.Empty) return null;
            var faq = GetEntityFaqById(ID);
            return ToModel(faq);
        }

        public IEnumerable<FAQModel> GetAll()
        {
            return context.Faqs.ToList().Select(x => this.ToModel(x)).OrderByDescending(x => x.Rating);
        }

        public IEnumerable<FAQModel> Firsts(int count)
        {
            return context.Faqs.ToList().Select(x => ToModel(x)).OrderByDescending(x => x.Rating).Take(count);
        }

        public PaginableList<FAQModel> GetPaginableList( FAQSearchModel search)
        {
            var query = context.Faqs.AsQueryable();

            if (!String.IsNullOrEmpty(search.Nombre))
            {
                query = query.Where(
                    x => (   x.Nombre.ToLower().Contains(search.Nombre.ToLower())
                          || x.Descripcion.ToLower().Contains(search.Nombre.ToLower())
                          || x.Solucion.ToLower().Contains(search.Nombre.ToLower())
                          || x.Tags.Any(t => t.Nombre.ToLower().Contains(search.Nombre.ToLower())))
                );
            }

            IEnumerable<FAQModel> list = query.ToList().Select(x => ToModel(x));

            return new PaginableList<FAQModel>(list, search);
        }

        public int Add(FAQModel faqModel)
        {
            var faqEntity = this.ToEntity(faqModel);
            

            if (faqModel.TagsId != null)
            {
                foreach (Guid tagId in faqModel.TagsId)
                {
                    var tag = new Tag
                    {
                        TagID = tagId
                    };
                    context.Tags.Attach(tag);
                    faqEntity.Tags.Add(tag);
                }
            }

            context.Faqs.Add(faqEntity);
            
            return context.SaveChanges();
        }

        public int Add(string nombre, string descripcion, TagListModel tags, string solucion, TipoModel tipo)
        {

            return Add(new FAQModel()
            {
                Nombre = nombre,
                Descripcion = descripcion,
                Tags = tags,
                Solucion = solucion,
                Tipo = tipo
            });
        }

        public int Update(FAQModel faqModel)
        {

            Entities.FAQ model = ToEntity(faqModel);
            //get current entry from db (db is context)
            var item = context.Entry<Entities.FAQ>(model);

            //change item state to modified
            item.State = System.Data.Entity.EntityState.Modified;

            //load existing items for ManyToMany collection
            item.Collection(i => i.Tags).Load();

            //clear Student items          
            model.Tags.Clear();

            //add Toner items
            foreach (var tagId in faqModel.TagsId)
            {
                var tag = context.Tags.Find(tagId);
                model.Tags.Add(tag);
            }

            return context.SaveChanges();
        }

        public int Qualify(FAQModel faqModel)
        {
            Entities.FAQ model = ToEntity(faqModel);
            context.Faqs.AddOrUpdate(model);
            return context.SaveChanges();
        }
        

        public int Delete(FAQModel faqModel)
        {
            context.Faqs.Remove(ToEntity(faqModel));
            return context.SaveChanges();
        }

        public int Delete(Guid ID)
        {
            context.Faqs.Remove(GetEntityFaqById(ID));
            return context.SaveChanges();
        }

        public IEnumerable<FAQModel> GetRelatedFaQs(Guid id)
        {
            var tag_list = context.Faqs.FirstOrDefault(x => x.FAQID == id).Tags.Select(x => x.TagID).ToList();

            //return db.Faqs.Where(x => x.Tags.Any(t => tag_list.Contains(t.TagID))).ToList().Select(x => ToModel(x));
            //return db.Faqs.Where(x => tag_list.FirstOrDefault(y => y == x.FAQID) != null).ToList().Select(x => ToModel(x));

            return context.Tags
                .Where(c => tag_list.Contains(c.TagID))
                .SelectMany(c => c.FAQs).Where(f => f.FAQID != id).Distinct().ToList().Select(x => ToModel(x)).Take(3);

        }
        public PaginableList<FAQModel> GetRelatedFaqsByTag(TagSearchModel search)
        {
            var query = context.Tags.Include(x => x.FAQs).FirstOrDefault(x => x.TagID == search.ModelID).FAQs.AsQueryable();

            if (!String.IsNullOrEmpty(search.Nombre))
            {
                query = query.Where(
                    x => (x.Nombre.ToLower().Contains(search.Nombre.ToLower())
                          || x.Descripcion.ToLower().Contains(search.Nombre.ToLower())
                          || x.Solucion.ToLower().Contains(search.Nombre.ToLower())
                          || x.Tags.Any(t => t.Nombre.ToLower().Contains(search.Nombre.ToLower())))
                );
            }

            var list = query.ToList().Select(x => ToModel(x));

            return new PaginableList<FAQModel>(list, search);
        }

        public bool ExistModel(FAQModel faqModel)
        {
            return context.Faqs.Any(f => f.Nombre.ToLower().Equals(faqModel.Nombre.ToLower()));
        }

        private Entities.FAQ GetEntityFaqById(Guid id)
        {
            return context.Faqs.Find(id);
        }
        
    }
}
