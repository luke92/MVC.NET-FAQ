﻿/* aux dom ready module */
(function (exports, d) {
    function domReady(fn, context) {

        function onReady(event) {
            d.removeEventListener('DOMContentLoaded', onReady);
            fn.call(context || exports, event);
        }

        function onReadyIe(event) {
            if (d.readyState === 'complete') {
                d.detachEvent('onreadystatechange', onReadyIe);
                fn.call(context || exports, event);
            }
        }

        d.addEventListener && d.addEventListener('DOMContentLoaded', onReady) ||
        d.attachEvent && d.attachEvent('onreadystatechange', onReadyIe);
    }

    exports.documentReady = domReady;
})(window, document);

/* main sso module */
(function (UA) {
    'use strict';

    var ssoUtils = {
        setCookie: function (cname, cvalue, exdays) {
            var d = new Date();
            d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
            var expires = 'expires=' + d.toUTCString();
            document.cookie = cname + '=' + cvalue + '; ' + expires;
        },
        getCookie: function (cname) {
            var name = cname + '=';
            var ca = document.cookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') c = c.substring(1);
                if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
            }
            return '';
        },
        ajaxGet: function(url, callbackOk, callbackError) {
            var xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
            xhr.open('GET', url);
            xhr.onreadystatechange = function() {
                if (xhr.readyState > 3) {
                    if (xhr.status === 200) {
                        callbackOk(xhr.responseText);
                    }
                    else {
                        callbackError(xhr);
                    }
                }
            };
            xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
            xhr.send();

            return xhr;
        },
        createMenu: function () {
            var bodyEl = document.getElementsByTagName('body')[0];

            var menuEl = document.createElement('div');
            menuEl.className = 'sso-menu';

            var firstElement = bodyEl.firstChild;
            bodyEl.insertBefore(menuEl, firstElement);

            return menuEl;
        },
        populateMenu: function (menuEl, sessionData, menu) {
            var menuList = document.createElement('ul');

            for (var index = 0; index < menu.menues.length; index++) {
                menuList.appendChild(ssoUtils.createMenuItem(menu.menues[index].name, menu.menues[index].url));
                if (index < menu.menues.length - 1)
                    menuList.appendChild(ssoUtils.createPipeItem("|"));
            }
            menuEl.appendChild(menuList);

            if (menu.nombre && menu.apellido) {
                var personaEl = document.createElement('div');
                personaEl.className = 'sso-persona';
                var apeYNom = document.createTextNode(menu.nombre + " " + menu.apellido);
                personaEl.appendChild(apeYNom);
                menuEl.appendChild(personaEl);
            }
        },
        createErrorMessage: function (menuEl, errorMessage) {
            var errorContainer = document.createElement('div');
            errorContainer.className = 'sso-menu-error';

            var errorText = document.createTextNode(errorMessage);
            errorContainer.appendChild(errorText);

            menuEl.appendChild(errorContainer);
        },
        createMenuItem: function(text, url) {
            var menuItem = document.createElement('li');
            var menuLink = document.createElement('a');
            var linkText = document.createTextNode(text);
            menuLink.href = url;
            menuLink.appendChild(linkText);
            menuItem.appendChild(menuLink);
            return menuItem;
        },
        createPipeItem: function(text) {
            var menuItem = document.createElement('li');
            var linkText = document.createTextNode(text);
            menuItem.appendChild(linkText);
            return menuItem;
        },
        log: function (message) {
            if (window.console) {
                window.console.log(message);
            }
        }
    }

    // declare sso object
    var ssoConnect = {
        init: function (sessionData) {
            if (!sessionData)
            {
                ssoUtils.log('No session data provided for SSO.');
                return;
            }

            var menuEl = ssoUtils.createMenu();

            // using sessionData.session.ticketId get menu information for user
            ssoUtils.ajaxGet(sessionData.session.ticket,
                function (result) {
                    // parse response
                    var menu = eval("(" + result + ")");

                    // create menu
                    ssoUtils.populateMenu(menuEl, sessionData, menu);
                },
                function (result) {
                    ssoUtils.createErrorMessage(menuEl, 'Ocurrio un error intentando obtener el menu de aplicaciones. (' + result.statusText + ')');
                    ssoUtils.log('Ocurrio un error intentando obtener el menu de aplicaciones. (' + result.statusText + ')');
                });
        }
    };

    // publish sso connect into UA namespace
    UA.ssoConnect = ssoConnect;

    // init SSO stuff
    var initFn = function () {
        UA.ssoConnect.init(window.ssoData);
    };

    // attach the evnet listener based on browser capabilities
    window.documentReady(initFn);

})(window.UA = window.UA || {});

