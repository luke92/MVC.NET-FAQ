﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HUA.FAQ.Data
{
    class FAQ
    {
        public Guid FaqID { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Solucion { get; set; }
    }
}
