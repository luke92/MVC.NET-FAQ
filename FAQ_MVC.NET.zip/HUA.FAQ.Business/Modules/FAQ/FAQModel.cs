﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using System.Web.WebPages;
using HUA.FAQ.Business.Modules.FAQ.Tag;
using HUA.FAQ.Business.Modules.FAQ.Tipo;

namespace HUA.FAQ.Business.Modules.FAQ
{
    public class FAQModel : GenericModel
    {
        [Required]
        [Display(Name = "Nombre:", Description = "")]
        [StringLength(300, ErrorMessage = "La pregunta no puede superar los 300 caracteres")]
        public string Nombre { get; set; }
        [Display(Name = "Descripción:", Description = "")]
        public string Descripcion { get; set; }
        [Display(Name = "Tags Relacionados:", Description = "")]
        public Guid[] TagsId { get; set; }
        public TagListModel Tags { get; set; }
        [Required]
        [Display(Name = "Solución:", Description = "")]
        [AllowHtml]
        public string Solucion { get; set; }
        [Display(Name = "Tipo:", Description = "")]
        public Guid TipoId { get; set; }
        [Display(Name = "Tipo:", Description = "")]
        public TipoModel Tipo { get; set; }
        public int Rating { get; set; }
        public int CantidadVotos { get; set; }

        public FAQListModel FaqsRelacionados { get; set; }
        public FAQModel()
        {
            Id = Guid.NewGuid();
            Nombre = "";
            Descripcion = "Sin Descripción";
            TagsId = new Guid[0];
            Solucion = "";
            TipoId = Guid.Empty;
            Tipo = new TipoModel();
            FaqsRelacionados = new FAQListModel();
            Rating = 0;
            CantidadVotos = 0;
            Tags = new TagListModel();
            
        }

        public FAQModel(string nombre, string descripcion, TagListModel tags, string solucion, TipoModel tipo)
        {
            Id = Guid.NewGuid();
            Nombre = nombre.Trim();
            Descripcion = descripcion.Trim();
            Tags = tags;
            Solucion = solucion.Trim();
            Tipo = tipo;
            FaqsRelacionados = new FAQListModel();
            Rating = 0;
            CantidadVotos = 0;
            TagsId = new Guid[0];
            TipoId = Guid.Empty;
        }

        public double PromedioCalificacion()
        {
            if (CantidadVotos == 0)
            {
                return 0;
            }

            double result = (double)Rating / CantidadVotos;
            return result;
        }

        public string ShortNombre()
        {
            int posLastChar = 50;

            if (Nombre.Length < posLastChar)
            {
                return Nombre;
            }

            return String.Format("{0}...", Nombre.Substring(0, posLastChar));
        }

        public string ShortDescripcion()
        {
            int posLastChar = 50;

            if (Descripcion.Length < 50)
            {
                return Descripcion;
            }

            return String.Format("{0}...", Descripcion.Substring(0, posLastChar));
        }

        public string ShortSolucion()
        {
            int posLastChar = 50;

            if (Solucion.Length < 50)
            {
                return Solucion;
            }

            return String.Format("{0}...", Solucion.Substring(0, posLastChar));
        }
    }
   
}
