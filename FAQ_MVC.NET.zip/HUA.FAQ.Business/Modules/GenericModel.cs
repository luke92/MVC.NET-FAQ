﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HUA.FAQ.Business.Modules
{
    public class GenericModel
    {
        public Guid Id { get; set; }

    }
}
