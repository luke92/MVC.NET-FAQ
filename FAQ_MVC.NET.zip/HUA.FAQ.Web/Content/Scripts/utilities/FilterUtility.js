﻿var filter = {
    /**
    * This funciton receives object parameters to bind elements to radio buttons. The attributes for the objects are as follows:
    * 
    * button: the radio button. string (id), DOM element (the radio button), jQuery (the radio button wrapped in a jQuery object)
    * show: the elements that should be shown when the button is selected. string[] (selectors), DOM element[] (the elements),
    *      jQuery[] (the elements each wrapped in a jQuery object), jQuery (all the elements wrapped in a single jQuery object)
    * hide: the elements that must always be hidden when the button is selected, even if they are not present in any of the 'shown'
    *      attributes of the other objects in the parameters. string[] (selectors), DOM element[] (the elements),
    *      jQuery[] (the elements each wrapped in a jQuery object), jQuery (all the elements wrapped in a single jQuery object)
    * selected: a boolean value that determines whether the button should be selected after the bindings are complete
    * 
    * If more than one object has 'selected: true', then the last button in the parameters with 'selected: true' will be selected.
    * The 'hide' attribute is optional. All elements passed in the 'show' attributes will be hidden whenever any of the buttons passed
    * in the 'button' attributes is clicked. If additional elements not present in the 'show' attributes wish to be hidden, they
    * must be specified in the 'hide' attribute.
    * 
    * Note: 'show' will be shown, and then 'hide' will be hidden. This allows the creation of a general selector for 'show', and 
    * then using 'hide' to hide a small amount of elements
    * 
    * @returns {} 
    */
    radioButton: function() {
        var objects = arguments;
        var allItems = []; // All the items to be used to create the unique items list
        var allItemsUnique = $(allItems);
// Unique items list, initialized as jQuery to set behavior in button.change() below
        var selected; // Variable to store the button with 'selected: true'

        for (var x = 0; x < objects.length; x++) {
            var object = objects[x];

            // START make sure button is jQuery object
            var button;
            var objectButton = object.button;
            if (objectButton instanceof jQuery) {
                // Already jQuery object
                button = objectButton;
            } else if (typeof objectButton === "string") {
                // Id selector. Check for #, remove if found, then find button
                if (objectButton.charAt(0) === "#") objectButton = objectButton.substr(1);
                button = $("#" + objectButton);
            } else {
                // DOM element. Wrap in jQuery object
                button = $(objectButton);
            }
            // END

            // START make show elements a jQuery object
            var showItems = [];
            var show = object.show;
            if (show != null) {
                if (show instanceof jQuery) {
                    // Already jQuery object
                    showItems = $.makeArray(show);
                } else {
                    // An array
                    for (var i = 0; i < show.length; i++) {
                        var showItem = show[i];
                        if (showItem instanceof jQuery) {
                            // Turn jQuery object into array, then put those array elements into showItems
                            showItems = showItems.concat($.makeArray(showItem));
                        } else {
                            // Use jQuery selector with the string or DOM element, turn to array, then concat to showItems
                            showItems = showItems.concat($.makeArray($(showItem)));
                        }
                    }
                }
            }
            // Add all show items from this button to the allItems array
            allItems = allItems.concat(showItems);
            showItems = $(showItems);
            // END

            // START make hide elements a jQuery object, if any
            var hideItems = [];
            var hide = object.hide;
            if (hide != null) { // 'hide' can be null
                if (hide instanceof jQuery) {
                    // Already jQuery object
                    hideItems = $.makeArray(hide);
                } else {
                    // An array
                    for (var j = 0; j < hide.length; j++) {
                        var hideItem = hide[j];
                        if (hideItem instanceof jQuery) {
                            // Turn jQuery object into array, then put those array elements into hideItems
                            hideItems = hideItems.concat($.makeArray(hideItem));
                        } else {
                            // Use jQuery selector with the string or DOM element, turn to array, then concat to hideItems
                            hideItems = hideItems.concat($.makeArray($(hideItem)));
                        }
                    }
                }
            }
            hideItems = $(hideItems);

            if (object.selected === true) selected = button;

            var callback = object.callback;

            // Finally, add click event to button
            (function(button, showItems, hideItems, callback) {
                button.click(function() {
                    allItemsUnique.hide();
                    showItems.show();
                    hideItems.hide();
                    if (callback != null) callback();
                });
            })(button, showItems, hideItems, callback);
        }

        allItemsUnique = []; // Turn into list to push items from allItems

        $.each(allItems,
            function(index, el) {
                if ($.inArray(el, allItemsUnique) === -1) allItemsUnique.push(el);
            });

        allItemsUnique = $(allItemsUnique); // Make jQuery object from array of DOM elements

        if (selected != null) selected.click();
    },
    /**
    * This funciton receives object parameters to bind elements to drop down lists. The attributes for the objects are as follows:
    * 
    * dropdown: the dropdown list (select). string (id), DOM element (the select), jQuery 
    *      (the select wrapped in a jQuery object)
    * show: the elements that should be shown when the button is selected. string[] (selectors), DOM element[] (the elements),
    *      jQuery[] (the elements each wrapped in a jQuery object), jQuery (all the elements wrapped in a single jQuery object)
    * hide: the elements that must always be hidden when the button is selected, even if they are not present in any of the 'shown'
    *      attributes of the other objects in the parameters. string[] (selectors), DOM element[] (the elements),
    *      jQuery[] (the elements each wrapped in a jQuery object), jQuery (all the elements wrapped in a single jQuery object)
    * selected: a boolean value that determines whether the button should be selected after the bindings are complete
    * 
    * If more than one object has 'selected: true', then the last button in the parameters with 'selected: true' will be selected.
    * The 'hide' attribute is optional. All elements passed in the 'show' attributes will be hidden whenever any of the buttons passed
    * in the 'button' attributes is clicked. If additional elements not present in the 'show' attributes wish to be hidden, they
    * must be specified in the 'hide' attribute.
    * 
    * Note: 'show' will be shown, and then 'hide' will be hidden. This allows the creation of a general selector for 'show', and 
    * then using 'hide' to hide a small amount of elements
    * 
    * @returns {} 
    */
    dropDown: function() {
        var objects = arguments;
        var allItems = [];                      // All the items to be used to create the unique items list
        var allItemsUnique = $(allItems);
                                                // Unique items list, initialized as jQuery to set behavior in button.change() below
        var selected;                           // Variable to store the button with 'selected: true'

        for (var x = 0; x < objects.length; x++) {
            var object = objects[x];

            // START make sure button is jQuery object
            var button;
            var objectButton = object.dropdown;
            if (objectButton instanceof jQuery) {
                // Already jQuery object
                button = objectButton;
            } else if (typeof objectButton === "string") {
                // Id selector. Check for #, remove if found, then find button
                if (objectButton.charAt(0) === "#") objectButton = objectButton.substr(1);
                button = $("#" + objectButton);
            } else {
                // DOM element. Wrap in jQuery object
                button = $(objectButton);
            }
            // END

            // START make show elements a jQuery object
            var showItems = [];
            var show = object.show;
            if (show != null) {
                if (show instanceof jQuery) {
                    // Already jQuery object
                    showItems = $.makeArray(show);
                } else {
                    // An array
                    for (var i = 0; i < show.length; i++) {
                        var showItem = show[i];
                        if (showItem instanceof jQuery) {
                            // Turn jQuery object into array, then put those array elements into showItems
                            showItems = showItems.concat($.makeArray(showItem));
                        } else {
                            // Use jQuery selector with the string or DOM element, turn to array, then concat to showItems
                            showItems = showItems.concat($.makeArray($(showItem)));
                        }
                    }
                }
            }
            // Add all show items from this button to the allItems array
            allItems = allItems.concat(showItems);
            showItems = $(showItems);
            // END

            // START make hide elements a jQuery object, if any
            var hideItems = [];
            var hide = object.hide;
            if (hide != null) { // 'hide' can be null
                if (hide instanceof jQuery) {
                    // Already jQuery object
                    hideItems = $.makeArray(hide);
                } else {
                    // An array
                    for (var j = 0; j < hide.length; j++) {
                        var hideItem = hide[j];
                        if (hideItem instanceof jQuery) {
                            // Turn jQuery object into array, then put those array elements into hideItems
                            hideItems = hideItems.concat($.makeArray(hideItem));
                        } else {
                            // Use jQuery selector with the string or DOM element, turn to array, then concat to hideItems
                            hideItems = hideItems.concat($.makeArray($(hideItem)));
                        }
                    }
                }
            }
            hideItems = $(hideItems);

            if (object.selected === true) selected = button;

            var callback = object.callback;

            // Finally, add click event to button
            (function(button, showItems, hideItems, callback) {
                button.click(function() {
                    allItemsUnique.hide();
                    showItems.show();
                    hideItems.hide();
                    if (callback != null) callback();
                });
            })(button, showItems, hideItems, callback);
        }

        allItemsUnique = []; // Turn into list to push items from allItems

        $.each(allItems,
            function(index, el) {
                if ($.inArray(el, allItemsUnique) === -1) allItemsUnique.push(el);
            });

        allItemsUnique = $(allItemsUnique); // Make jQuery object from array of DOM elements

        if (selected != null) object.dropdown.val(selected.val());
    }
}