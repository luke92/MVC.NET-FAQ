﻿using System.Web.Mvc;
using FluentAssertions.Mvc;
using HUA.FAQ.Entities;
using HUA.FAQ.Web.Controllers;
using NSubstitute;
using Xunit;

namespace HUA.FAQ.Web.Tests.Controllers
{

    public class HomeControllerTest
    {

        [Fact]
        public void La_vista_index_obtiene_datos_en_ViewBag()
        {
            // Given
            // tengo el controlador del HOME
            var mockContext = Substitute.For<IFaqContext>();

            HomeController controller = new HomeController(mockContext);

            // When
            // Llamo a la vista Index
            var result = controller.Index();

            // Then
            result.Should()
                .BeViewResult()
                .WithDefaultViewName();
        }
        

    }
}
