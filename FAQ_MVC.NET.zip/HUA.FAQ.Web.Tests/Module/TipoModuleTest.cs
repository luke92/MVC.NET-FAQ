﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Diagnostics.Contracts;
using HUA.FAQ.Business.Modules.FAQ;
using HUA.FAQ.Business.Modules.FAQ.Tipo;
using HUA.FAQ.Entities;
using System.Linq;
using System.Web.Hosting;
using FluentAssertions;
using Moq;
using NSubstitute;
using Xunit;

namespace HUA.FAQ.Web.Tests.Module
{
    public class TipoModuleTest
    {

        [Fact]
        public void test_para_probar_el_metodo_to_entity()
        {
            var mockContext = Substitute.For<IFaqContext>();
            TipoModule tipoModule = new TipoModule(mockContext);
            // Given
            string miNombre = Utils.RandomString(50);
            // Un objeto de la clase TipoModel
            TipoModel tipoModel = new TipoModel()
            {
                Nombre = miNombre
            };

            // When
            // Paso el TipoModel a la entidad

            Tipo tipoEntity = tipoModule.ToEntity(tipoModel);

            // Then
            // El nombre de la entidad es igual al del modelo
            tipoEntity.Nombre
                .Should()
                .Be(miNombre);

        }


        [Fact]
        public void se_puede_almacenar_un_modelo_en_la_BD()
        {
            var mockContext = Substitute.For<IFaqContext>();
            TipoModule tipoModule = new TipoModule(mockContext);
            // Given
            string miNombre = Utils.RandomString(50);
            // Un objeto de la clase TipoModel
            TipoModel tipoModel = new TipoModel()
            {
                Nombre = miNombre,
                Id = Guid.NewGuid()
            };

            Tipo tipoEntity = tipoModule.ToEntity(tipoModel);


            var data = new List<Tipo>
            {
                new Tipo { TipoID = Guid.NewGuid(), Nombre = Utils.RandomString()},
                new Tipo { TipoID = Guid.NewGuid(), Nombre = Utils.RandomString() },
                new Tipo { TipoID = Guid.NewGuid(), Nombre = Utils.RandomString() },
            };

            var mockSet = Utils.CreateMockDbSet(data);
            
            mockContext.Tipos.Returns(mockSet);
            mockContext.SaveChanges().Returns(1);


            // When
            // Almaceno la entidad
            int respuesta = tipoModule.Add(tipoModel);


            // Then
            // El nombre de la entidad es igual al del modelo
            respuesta.Should().Be(1);

            // verify that DbSet.Add has been called once
            mockSet.Received(1).Add(Arg.Any<Tipo>());
        }

    }
}
