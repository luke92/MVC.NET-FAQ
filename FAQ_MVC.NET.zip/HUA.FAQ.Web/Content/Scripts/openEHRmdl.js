﻿$(
    $("main").on('click',
        '.dropdown-item',
        function () {
            
            var elemClass = $(this).attr("class");
            elemClass = elemClass.substring(elemClass.lastIndexOf("dropdownMenu"), elemClass.lastIndexOf("-item"));
            $("#" + elemClass + "-button").text($(this).text());
            $("#" + elemClass + "-input").val($(this).attr("value"));
            $("#" + elemClass + "-button").removeClass("invalidDrop");
            $("#" + elemClass + "-button").next("span").css("visibility", "hidden");
            //debugger;
            if (typeof $("#" + elemClass + "-input").next() != 'undefined') {
                $("#" + elemClass + "-input").next().val($(this).attr("key"));
            }
            $("#" + elemClass + "-input").change();
        })
);

$(
    $("main").on('click',
        ".dateInput",
        function (event) {
            debugger;
            // Permite solo fechas futuras hasta 10 años
            const elemId = $(this).attr("id");
            var data = $(this).val();
            const dialog = new mdDateTimePicker.default({
                type: 'date',
                past: moment().subtract(0, 'years'),
                future: moment().add(10, 'years'),
                cancel: "Cancelar",
                mode: true,
                init: data === "" ? moment() : moment(data, "DD/MM/YYYY")
            });
            dialog.trigger = document.getElementById(elemId);
            document.getElementById(elemId).addEventListener('onOk', 
                function () {
                    this.value = dialog.time.format("DD/MM/YYYY");
                    $(this).change();
                });
            dialog.toggle();
        })
);
$(
    $("main").on('click',
        ".dateInput2",
        function () {
            ////debugger;
            const elemId = $(this).attr("id");
            var data = $(this).data("date");
            const dialog = new mdDateTimePicker.default({
                type: 'date',
                // Permite fechas de 10 en el pasado y 10 en el futuro
                past: moment().subtract(10, 'years'),
                future: moment().add(10, 'years'),
                mode: true,
                init: data === "" ? moment() : moment(data)
                });
                dialog.trigger = document.getElementById(elemId);
                document.getElementById(elemId).addEventListener('onOk',
                    function () {
                        this.value = dialog.time.format('DD/MM/YYYY').toString();
                    $(this).data("date", dialog.time.toString());
                    });
                dialog.toggle();
        })
);
$(
$("main").on('click',
    ".timeInput",
    function (event) {
        debugger;
        const elemId = $(this).attr("id");
        var data = $(this).data("time");
        const dialog = new mdDateTimePicker.default({
            type: 'time',
            mode: true,
            init: data === "" ? moment() : moment(data)
        });
        dialog.trigger = document.getElementById(elemId);
        document.getElementById(elemId).addEventListener('onOk',
            function() {
                $(this).val(dialog.time.format("HH:mm").toString());
                $(this).data("time", dialog.time.toString());
                $(this).change();
            });
        dialog.toggle();
            
        //$("#divId").css({ position: "absolute", top: event.pageY, left: event.pageX });
        $("#mddtp-picker__time").removeClass('mddtp-picker-time');
    })

);

const JSONDateToJavascriptDate = function(JSONdate) {
    var date = new Date(+JSONdate.match(/\d+/)[0]);
    return date;
}

const DateToddMMyyyy = function(date) {
    var month = date.getMonth() + 1;
    var day = date.getDate();
    var year = date.getFullYear();
    if (day < 10) {
        day = '0' + day;
    }
    if (month < 10) {
        month = '0' + month;
    }
    var date = day + "/" + month + "/" + year;
    return date;
}