﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HUA.FAQ.Business.Modules.FAQ
{
    public class PaginableList<T>
    {
        public int TotalPage { get; set; }
        public int PageSize { get; set; }
        public IEnumerable<T> list { get; set; }
        public int CurrentPage { get; set; }
        public int TotalCount { get; set; }
        public ISearchModel Search { get; set; }

        public PaginableList (IEnumerable<T> list, int currentPage, int pageSize)
        {
            this.TotalCount = list.Count();
            this.PageSize = pageSize;
            this.TotalPage = (int)Math.Ceiling(this.TotalCount / (double)PageSize);
            this.CurrentPage = currentPage;
            this.list = list.Skip((currentPage - 1) * pageSize).Take(this.PageSize);
        }

        public PaginableList(IEnumerable<T> list, ISearchModel search)
        {
            this.TotalCount = list.Count();
            this.PageSize = search.PageSize();
            this.TotalPage = (int)Math.Ceiling(this.TotalCount / (double)PageSize);
            this.CurrentPage = search.CurrentPage();
            this.list = list.Skip((this.CurrentPage - 1) * this.PageSize).Take(this.PageSize);
            this.Search = search;
        }
    }
}
