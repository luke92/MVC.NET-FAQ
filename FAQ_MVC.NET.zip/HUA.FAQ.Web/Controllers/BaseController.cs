﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HUA.FAQ.Web.Controllers
{
    public class BaseController : Controller
    {
        // GET: Base
        [ChildActionOnly]
        public ActionResult SubMenu()
        {
            var menu = new MenuModel
            {
                Items = new List<MenuItemModel>
                   {
                       new MenuItemModel { Text = "Menu" }

                   }
            };

            menu.Items[0].Items.Add(new MenuItemModel { Text = "Lista FAQ", Controller = "FAQ", Action = "Index" });
            menu.Items[0].Items.Add(new MenuItemModel { Text = "Lista TAG", Controller = "TAG", Action = "Index" });
            menu.Items[0].Items.Add(new MenuItemModel { Text = "Lista Tipos", Controller = "Tipo", Action = "Index" });
            //menu.Items[0].Items.Add(new MenuItemModel { Text = "Contact", Controller = "Home", Action = "Contact" });
            //menu.Items[0].Items.Add(new MenuItemModel { Text = "About", Controller = "Home", Action = "About" });

            return PartialView(menu);
        }

        public class MenuModel
        {
            public IList<MenuItemModel> Items { get; set; }

            public MenuModel()
            {
                this.Items = (IList<MenuItemModel>)new List<MenuItemModel>();
            }

            public void SelectItemByController(string controller)
            {
                MenuItemModel menuItemModel = this.Items.SelectMany((Func<MenuItemModel, IEnumerable<MenuItemModel>>)(item => (IEnumerable<MenuItemModel>)item.Items), (item, subItem) =>
                {
                    var data = new { item = item, subItem = subItem };
                    return data;
                }).Where(_param1 => _param1.subItem.Controller.Equals(controller, StringComparison.InvariantCultureIgnoreCase)).Select(_param0 => _param0.subItem).FirstOrDefault<MenuItemModel>();
                if (menuItemModel == null)
                    return;
                menuItemModel.IsSelected = true;
            }
        }
        public class MenuItemModel
        {
            public string Text { get; set; }

            public string ImageUrl { get; set; }

            public string Action { get; set; }

            public string Controller { get; set; }

            public bool IsSelected { get; set; }

            public IList<MenuItemModel> Items { get; set; }

            public Guid MenuItemGuid { get; set; }

            public string ToolTip { get; set; }

            public MenuItemModel()
            {
                this.IsSelected = false;
                this.Items = (IList<MenuItemModel>)new List<MenuItemModel>();
            }
        }
    }
}