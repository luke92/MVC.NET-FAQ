﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using HUA.FAQ.Business.Modules.FAQ.Tag;
using HUA.FAQ.Business.Modules.FAQ.Tipo;
using HUA.FAQ.Entities;

namespace HUA.FAQ.Business.Modules.FAQ
{
    public class TagModule
    {
        private IFaqContext db;

        public TagModule(IFaqContext _context)
        {
            db = _context;
        }
        public Entities.Tag ToEntity(TagModel faqModel)
        {
            return new Entities.Tag()
            {
                TagID = faqModel.Id,
                Nombre = faqModel.Nombre
            };
        }

        public List<Entities.Tag> ToEntities(TagListModel lista)
        {
            return lista.Items.Select(item => ToEntity(item)).ToList();
        }

        public TagModel ToModel(Entities.Tag tag)
        {
            return new TagModel()
            {
                Id = tag.TagID,
                Nombre = tag.Nombre
            };
        }

        public TagListModel ToModels(List<Entities.Tag> tags)
        {
            return new TagListModel()
            {
                Items = tags.Select(item => ToModel(item)).ToList()
            };
        }

        public TagModel Get(Guid ID)
        {
            if (ID == Guid.Empty) return null;
           
            
            return ToModel(db.Tags.Find(ID));
        }

        public PaginableList<TagModel> List(TagSearchModel search)
        {
           
            var query = db.Tags.AsQueryable();

            if (!String.IsNullOrEmpty(search.Nombre))
            {
                query = query.Where(x => x.Nombre.ToLower().Contains(search.Nombre.ToLower()));
            }

            IEnumerable<TagModel> list = query.ToList().Select(x => ToModel(x));

            return new PaginableList<TagModel>(list, search);
        }

        public bool ExistModel(TagModel tagModel)
        {
           
            return db.Tags.Any(t => t.Nombre.ToLower().Equals(tagModel.Nombre.ToLower()));
        }

        public IEnumerable<TagModel> All()
        {
           
            return db.Tags.ToList().Select(x => ToModel(x));
        }

        public IEnumerable<TagModel> GetRamdom(int count)
        {
            
            return db.Tags.OrderBy(x => Guid.NewGuid()).Take(count).ToList().Select(x => ToModel(x));
        }

        public int Add(TagModel tagModel)
        {
            db.Tags.Add(ToEntity(tagModel));
            return db.SaveChanges();
        }

        public int Add(string nombre)
        {
            return Add(new TagModel()
            {
                Nombre = nombre
            });
        }

        public int Update(TagModel tagModel)
        {
           
            var tagEntity = ToEntity(tagModel);
            db.Tags.Attach(tagEntity);
            db.Entry(tagEntity).State = EntityState.Modified;
            return db.SaveChanges();
        }

        public int Delete(TagModel tagModel)
        {
           
            db.Tags.Remove(ToEntity(tagModel));
            return db.SaveChanges();
        }

        public int Delete(Guid ID)
        {
            
            db.Faqs.Remove(db.Faqs.Find( db ,ID));
            return db.SaveChanges();
        }
    }
}
