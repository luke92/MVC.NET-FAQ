﻿$(document).ready(function () {
    $(function () {
        $("#SearchNombre").autocomplete({
            source: function (request, response) {
                $.ajax({
                    type: "POST",
                    url: "/FAQ/FAQ/Autocomplete",
                    data: request,
                    success: response,
                    dataType: 'json'
                });
            },
            minLength: 3
        });
    });
});
