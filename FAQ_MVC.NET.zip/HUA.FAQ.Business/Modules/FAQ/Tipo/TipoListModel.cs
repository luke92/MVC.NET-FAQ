﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HUA.FAQ.Business.Modules.FAQ.Tipo
{
    public class TipoListModel
    {
        public List<TipoModel> Items { get; set; }

        public override string ToString()
        {
            string aux = "";
            foreach (var item in Items)
            {
                aux += item.Nombre + ", ";
            }

            return aux;
        }

        public TipoListModel(List<TipoModel> tipoModels)
        {
            Items = new List<TipoModel>();
            Items.AddRange(tipoModels);
        }

        public TipoListModel()
        {
            Items = new List<TipoModel>();
        }
    }
}
