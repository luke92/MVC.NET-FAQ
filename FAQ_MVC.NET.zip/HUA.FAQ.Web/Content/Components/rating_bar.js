﻿const domContainer = document.querySelector('#calificacion_prom');
ReactDOM.render(e(LikeButton), domContainer);