﻿namespace HUA.FAQ.Business.Modules.FAQ
{
    public interface ISearchModel
    {
        int CurrentPage();
        int PageSize();
        int AddPages(int add);
        int SetPages(int page);
        ISearchModel NextPage();
        ISearchModel PreviousPage();
        ISearchModel SaltPage(int page);
    }
}