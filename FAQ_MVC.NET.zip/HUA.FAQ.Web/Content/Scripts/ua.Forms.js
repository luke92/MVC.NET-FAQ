﻿$.ajaxSetup({ cache: false });

function initializeForm() {

    $('input[type=text],select').each(function () {
        var req = $(this).attr('data-val-required');
        if (undefined != req) {
            var label = $('label[for="' + $(this).attr('id') + '"]');
            var text = label.text();
            if (text.length > 0) {
                label.append('<span style="color:red"> *</span>');
            }
        }
    });
    
    if ($("#controlNameToFocus").val() != undefined) {
        $($("#controlNameToFocus").val()).focus();
    }
    else {
        $('input:visible:enabled:first').focus();
    }

    switchEditMode();
}

function initializeTabs() {

    var items = $('.scrollable > .items').children();
    var containerWidth = $('.scrollable').width();

    var accum = 0;
    var page = 1;

    $.each(items, function () {

        accum += $(this).outerWidth();
        if (accum >= containerWidth) {
            accum = 0;
            page += 1;
        }

        $(this).addClass('tabs-page-' + page);

    });

    for (var i = 1; i <= page; i++) {
        $('.tabs-page-' + i).wrapAll('<div/>');
    }

    $(".scrollable").scrollable();
}

function initializeGridsIfAny() {
    var table = $('.tablesorter');

    if (table) {
        var length = $('tr', table.find('tbody')).length;

        if (length > 0) {
            table.tablesorter({ dateFormat: "uk" })
                 .tablesorterPager({ container: $("#tablesorterPager"), positionFixed: false });
        }
    }
}

function initializeGridsWithoutPagerIfAny() {
    var table = $('.tablesorter');

    if (table) {
        var length = $('tr', table.find('tbody')).length;

        if (length > 0) {
            table.tablesorter({ dateFormat: "uk" });
        }
    }
}

function removeAllValidationErrors() {

    $('.field-validation-error').each(function () {
        $(this).removeClass('field-validation-error');
        $(this).addClass('field-validation-valid');
    });

    $('.input-validation-error').removeClass('input-validation-error');
    $('.validation-summary-errors').hide();
}

$(window).keydown(function (event) {
    if (event.keyCode == 13) {
        event.preventDefault();
        return false;
    }
});

function checkSession(data) {
    if (data == "not_logged") {
        top.NotLogued();
        return false;
    }

    if (data == "not_authorized") {
        top.Unauthorized();
        return false;
    }

    return true;
};

$(".jsCreate").live("click", function (event) {
    event.preventDefault();

    var postData = {};
    if ($(this).data('postData') != undefined)
        postData = $(this).data('postData');

    showLoading();

    $.get(event.target.href, postData,
    function (data) {
        if (checkSession(data)) {
            $(".row-selected").removeClass("row-selected");
            $(".edition-panel").html(data);
            initializeForm();
        }
    })
    .success(function () { })
    .error(function () { showErrorMessage("Ocurrió un error"); })
    .complete(function () {
        hideLoading();
        initializeTabs();
        
    });
});

function loadEditionPanel(url, postData) {
    showLoading();

    $.get(url, postData,
    function (data) {
        if (checkSession(data)) {
            $(".edition-panel").html(data);
            initializeForm();
        }
    })
    .success(function () { })
    .error(function () { showErrorMessage("Ocurrió un error"); })
    .complete(function () {
        hideLoading();
        initializeTabs();
    });
}

function loadInlineViewPanel(url, postData) {
    showLoading();

    $.get(url, postData,
    function (data) {
        if (checkSession(data)) {
            $(".edition-panel-inline").html(data);
        }
    })
    .success(function () { })
    .error(function () { showErrorMessage("Ocurrió un error"); })
    .complete(function () {
        hideLoading();
        initializeTabs();
    });
}

$(".jsEdit").live("click", function (event) {
    event.preventDefault();

    var postData = {};
    if ($(this).data('postData') != undefined)
        postData = $(this).data('postData');

    loadEditionPanel(event.target.href, postData);
});

$(".jsView").live("click", function (event) {
    event.preventDefault();

    var postData = {};
    if ($(this).data('postData') != undefined)
        postData = $(this).data('postData');

    loadEditionPanel(event.target.href, postData);
});

$(".jsInlineView,.jsTextInlineView").live("click", function (event) {
    event.preventDefault();

    var postData = {};
    if ($(this).data('postData') != undefined)
        postData = $(this).data('postData');

    loadInlineViewPanel(event.target.href, postData);
});

$(".jsAttach").live("click", function (event) {
    event.preventDefault();

    var postData = {};
    if ($(this).data('postData') != undefined)
        postData = $(this).data('postData');

    loadEditionPanel(event.target.href, postData);
});

$(".jsDelete").live("click", function (event) {
    event.preventDefault();

    if (!confirm("Seguro de eliminar el registro seleccionado?"))
        return;

    var postData = {};
    if ($(this).data('postData') != undefined)
        postData = $(this).data('postData');

    var parentKey = {};
    if ($(this).data('parentKey'))
        parentKey = $(this).data('parentKey').Value;

    $.ajax({
        type: "post",
        url: event.target.href,
        data: postData
    })
    .done(function (data) {
        if (checkSession(data)) {
            if (data.Result == "Ok") {
                reloadList(parentKey);
            }
            else {
                if (data.Result == "Error")
                    alert(data.Messaje);
                $(".edition-panel").html(data);
            }
        }
    })
    .fail(function (jqXHR, textStatus) { showErrorMessage("Ocurrió un error"); })
    .always(function () {
        initializeTabs();
    });
});

$(".jsSelectRow").live("click", function (event) {
    event.preventDefault();

    if ($(this).data("editable") != 'False') {
        $(".action-bar .jsEdit").show();
        $(".action-bar .jsEdit").data('postData', $(this).data());
    } else {
        $(".action-bar .jsEdit").hide();
    }
    
    if ($(this).data("deleteable") != 'False') {
        $(".action-bar .jsDelete").show();
        $(".action-bar .jsDelete").data('postData', $(this).data());
    } else {
        $(".action-bar .jsDelete").hide();
    }

    $(".row-selected").removeClass("row-selected");
    $(this).addClass('row-selected');
});

$(".jsSave").live("click", function (event) {
    event.preventDefault();

    var formData = $(event.target).parents("form").serialize();
    var formAction = $(event.target).parents("form").attr("action");
    var formMethod = $(event.target).parents("form").attr("method");

    var successMessage = "Los datos fueron guardados con éxito";

    showLoading();

    $("#error-message").hide();

    $.ajax({
        type: formMethod,
        url: formAction,
        data: formData
    })
    .done(function (data) {
        if (checkSession(data)) {
            if (data.Result == "Ok") {
                removeAllValidationErrors();
                if (data.PostAction != undefined) {
                    $.get(data.PostAction, {}, function (result) {
                        $(".edition-panel").html(result);
                        initializeForm();
                        showSuccessMessage(successMessage);
                    })
                    .success(function () { })
                    .error(function () { })
                    .complete(function () {
                        initializeTabs();
                    });
                }
                else if (data.PostScript)
                {
                   AfterSaveHandler(data);
                }
                else {
                    showSuccessMessage(successMessage);
                }
            }
            else {
                if (data.Message) {
                    $("#error-message").html(data.Message);
                    $("#error-message").show();
                }
                else {
                    $(".edition-panel").html(data);
                    initializeForm();
                    showErrorMessage("Ocurrió un error");
                }
            }
        }
    })
    .fail(function (jqXHR, textStatus) { showErrorMessage("Ocurrió un error"); })
    .always(function () {
        hideLoading();
        initializeTabs();
    });
});

$(".jsCancel").live("click", function (event) {
    event.preventDefault();

    if ($(".list-panel").length > 0) {
        reloadList();
        $(".edition-panel").html("");
        switchListMode();
    }
    else {
        reloadEdit();
    }
});

function reloadList(activeKey) {

    if ($(".list-panel").length > 0) {

        var isTree = pageContainsTree();
        var postReloadAction;
        var selectedId;

        if (isTree)
        {
            postReloadAction = function (data) {
                var node = $("#tree").dynatree("getActiveNode");

                if (node != null) {
                    var key = node.data.key;

                    if (activeKey)
                        key = activeKey;
                }

                $(".list-panel").html(data);

                if (node != null) {
                    $("#tree").dynatree("getTree").activateKey(key);
                    node = $("#tree").dynatree("getActiveNode");

                    if (node != null)
                        node.expand(true);
                }
            };
        }
        else //if its a list
        {
            postReloadAction = function (data) {
                selectedId = $(".list-panel .row-selected").data("id");
                $(".list-panel").html(data);
                $(".list-panel tr[data-id='" + selectedId + "']").addClass('row-selected');
                initializeGridsIfAny();
            };
        }

        showLoading();

        var params = {};
        if ($(".list-panel").data('params')) {
            params = $(".list-panel").data('params');
        }

        $.get($(".list-panel").data('url'), params, function (data) {
            postReloadAction(data);
            switchListMode();
        })
        .success(function () { })
        .error(function () { })
        .complete(function () { hideLoading(); });

    }

}

function reloadEdit() {
    showLoading();

    $.get($(".edition-panel").data('url'), function (data) {
        $(".edition-panel").html(data);
    })
    .success(function () { })
    .error(function () { })
    .complete(function () { hideLoading(); initializeTabs(); });
}

function pageContainsTree() {
    return $(".list-panel > #tree").length > 0;
}

function reloadDetails(id) {
    if ($(".details-panel").length > 0) {
        if ($(".details-panel").data('id') != undefined) {
            $.get($(".details-panel").data('url'), { Id: $(".details-panel").data('id') },
            function (data) {
                $(".details-panel").html(data);

                switchListMode();
            })
            .success(function () { })
            .error(function () { })
            .complete(function () { });
        }
    }
}

function switchListMode() {
    $(".list-panel").show();
    $(".action-bar").show();
    $(".details-panel").show();
    $(".edition-panel").hide();
}

function switchEditMode() {
    $(".list-panel").hide();
    $(".action-bar").hide();
    $(".details-panel").hide();
    $(".edition-panel").show();
}

function showSuccessMessage(message) {
    $("#message-panel").removeClass().addClass("success").html(message).fadeIn('fast', function () {
        $(this).fadeOut(3000);
    });
}

function showErrorMessage(message) {
    $("#message-panel").removeClass().addClass("error").html(message).fadeIn('fast', function () {
        $(this).fadeOut(6000);
    });
}

function showLoading() {
    $("#loading-panel").show();
}

function hideLoading() {
    $("#loading-panel").hide();
}

/* Global ajax behavior managers */
$("#loading-panel").ajaxStart(function () {
});

$('#loading-panel').ajaxComplete(function (e, xhr, settings) {
});

String.prototype.format = function () {
    var args = arguments;
    return this.replace(/\{\{|\}\}|\{(\d+)\}/g, function (m, n) {
        if (m == "{{") { return "{"; }
        if (m == "}}") { return "}"; }
        return args[n];
    });
};

/* INICIO - Codigo JS creado por el equipo de la Universidad autral */
// Setear class "jsOnlyNum" para que solo se puedan ingresar numeros en un campo especifico.
$(".jsOnlyNum").live("keyup", function () {
    if ($(this).val() != "")
        $(this).val($(this).val().replace(/[^0-9\.]/g, ""));
});
// Setar class "jsEditRow" para que la fila sea editable
$(".jsEditRow").live("click", function () {
    $(this).parents("tr").find('input').attr({ readonly: false });
    $(this).parents("tr").find('input').css("background-color", "#FFFFCC");
    $(this).parents("tr").find('.readonlyField:checkbox').unbind("click");
});


/* FIN - Codigo JS creado por el equipo de la Universidad autral */
