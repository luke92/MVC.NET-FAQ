﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Web.ModelBinding;
using FluentAssertions;
using HUA.FAQ.Business.Modules.FAQ;
using HUA.FAQ.Business.Modules.FAQ.Tag;
using HUA.FAQ.Entities;
using NSubstitute;
using Xunit;

namespace HUA.FAQ.Web.Tests.Module
{

    public class TagModuleTest
    {
      

        [Fact]

        public void se_puede_almacenar_un_Tag_en_la_BD()
        {

            var mockContext = Substitute.For<IFaqContext>();
            TagModule tagModule = new TagModule(mockContext);
            // Given
            // Un objeto de la clase TipoModel
            TagModel tagModel = new TagModel()
            {
                Nombre = Utils.RandomString(50),
                Id = Guid.NewGuid()
            };

            // Mock de guardado en la BD
            Tag tipoEntity = tagModule.ToEntity(tagModel);

            var data = new List<Tipo>
            {
                new Tipo { TipoID = Guid.NewGuid(), Nombre = Utils.RandomString()},
                new Tipo { TipoID = Guid.NewGuid(), Nombre = Utils.RandomString() },
                new Tipo { TipoID = Guid.NewGuid(), Nombre = Utils.RandomString() },
            };

            var mockSet = Utils.CreateMockDbSet(data);
            
            mockContext.Tipos.Returns(mockSet);
            mockContext.SaveChanges().Returns(1);

            // When
            // Almaceno la entidad
            int respuesta = tagModule.Add(tagModel);


            // Then
            // El nombre de la entidad es igual al del modelo
            respuesta.Should().Be(1);

            // verify that DbSet.Add has been called once
            mockSet.Received(1).Add(Arg.Any<Tipo>());
        }

        //[Fact]

    //public void trae_lista_completa_de_Tag()
    //    {
    //        var context =new  FAQContext();

    //        var List = context.Tags.ToList();

    //        IEnumerable<TagModel> respuesta = TagModule.All();

    //        respuesta.Should().Equal((List.Count(), respuesta.Count()));

    //    }

      

        //[Fact]

        //public void Buscar_Tag_por_un_Parametro()
        //{

        //    TagSearchModel searcher = new TagSearchModel();

        //    var context = new FAQContext();

        //    var List = context.Tags.ToList();

        //    PaginableList<TagModel> respuesta = TagModule.List(searcher);

        //    Assert.IsNotNull(respuesta);

        //}


    }
}
