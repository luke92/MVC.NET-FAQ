﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HUA.FAQ.Entities
{
    public class Tag
    {
        public Guid TagID { get; set; }

        [Required]
        [Index(IsUnique = true)]
        [StringLength(50, MinimumLength = 3)]
        public string Nombre { get; set; }

        public virtual List<FAQ> FAQs { get; set; }

        public Tag()
        {
            TagID = Guid.NewGuid();
            FAQs = new List<FAQ>();
        }
    }

}
