﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentAssertions;
using HUA.FAQ.Business.Modules;
using HUA.FAQ.Business.Modules.FAQ;
using HUA.FAQ.Business.Modules.FAQ.Tag;
using HUA.FAQ.Business.Modules.FAQ.Tipo;
using HUA.FAQ.Entities;
using Xunit;

namespace HUA.FAQ.Web.Tests.Module
{
    public class FAQModuleTest
    {

        [Fact]
        public void ToEntityTest()
        {
            FAQModule faqModule = new FAQModule(new FaqContext());
            var model = GetFaqModel();
            var entity = faqModule.ToEntity(model);
            entity.Nombre.Should().Be(model.Nombre);
        }

        [Fact]
        public void ToModelTest()
        {
            FAQModule faqModule = new FAQModule(new FaqContext());
            var entity = GetFaqEntity();
            var model = faqModule.ToModel(entity);
            model.Nombre.Should().Be(entity.Nombre);
        }

        [Fact]
        public void AddTest()
        {

        }

        [Fact]
        public void UpdateTest()
        {

        }

        [Fact]
        public void DeleteTest()
        {

        }

        [Fact]
        public void GetSugerenciasTest()
        {

        }

        [Fact]
        public void GetByIdTest()
        {

        }

        [Fact]
        public void AllTest()
        {

        }

        [Fact]
        public void FirstsFaqsByCantTest()
        {

        }

        [Fact]
        public void ListFaqsBySearchTest()
        {

        }


        private static FAQModel GetFaqModel()
        {
            var tipo = new TipoModel()
            {
                Id = Guid.NewGuid(),
                Nombre = "TipoFaqModelTest"
            };
            return new FAQModel()
            {
                Nombre = "FaqModelTest",
                Descripcion = "FaqModelTest",
                Solucion = "FaqModelTest",
                TipoId = tipo.Id,
                Tipo = tipo
            };
            
        }

        private Entities.FAQ GetFaqEntity()
        {
            var tipo = new Tipo()
            {
                TipoID = Guid.NewGuid(),
                Nombre = "TipoEntityTest"
            };
            return new Entities.FAQ()
            {
                FAQID = Guid.NewGuid(),
                Nombre = "FaqEntityTest",
                Descripcion = "FaqEntityTest",
                Solucion = "FaqEntityTest",
                Tipo = tipo,
                TipoId = tipo.TipoID,
            };
        }


}
}
