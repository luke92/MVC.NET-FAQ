﻿using System.Data.Entity;
using HUA.FAQ.Entities;

namespace HUA.FAQ.Business.Modules.FAQ
{
    public class TagFaqModule
    {
        public static void Update(IFaqContext context, FAQModule faqModule, FAQModel faqModel)
        {

            var faqEntity = faqModule.ToEntity(faqModel);
            using (var db = new FaqContext())
            {
                var faq = db.Faqs.Find(faqEntity.FAQID);
                if (faq == null) return;
                foreach (var tag in faqEntity.Tags)
                {
                    db.Entry<Entities.Tag>(tag).State = EntityState.Unchanged;
                }
                faq.Tags.Clear();
                faq.Tags.AddRange(faqEntity.Tags);
                db.SaveChanges();
            }
        }
    }
}
