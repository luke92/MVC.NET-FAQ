﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Common;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HUA.FAQ.Entities
{
    public interface IFaqContext : IDisposable
    {

        DbSet<FAQ> Faqs { get; set; }
        DbSet<Tag> Tags { get; set; }
        DbSet<Tipo> Tipos { get; set; }
        DbSet<User> Users { get; set; }

        Database Database { get; }

        DbSet<TEntity> Set<TEntity>() where TEntity : class;

        DbSet Set(Type entityType);

        int SaveChanges();

        Task<int> SaveChangesAsync();

        IEnumerable<DbEntityValidationResult> GetValidationErrors();

        DbEntityEntry<TEntity> Entry<TEntity>(TEntity entity) where TEntity : class;

        DbEntityEntry Entry(object entity);

        DbChangeTracker ChangeTracker { get; }

        DbContextConfiguration Configuration { get; }
        
    }
}
