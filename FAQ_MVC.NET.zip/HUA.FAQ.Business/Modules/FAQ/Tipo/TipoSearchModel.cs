﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HUA.FAQ.Business.Modules.FAQ.Tipo
{
    public class TipoSearchModel : SearchModel
    {
        public String Nombre { get; set; }

        public TipoSearchModel() : base()
        {
            this.Nombre = "";
        }

        public override string ToString()
        {
            return this.Nombre;
        }
    }
}
