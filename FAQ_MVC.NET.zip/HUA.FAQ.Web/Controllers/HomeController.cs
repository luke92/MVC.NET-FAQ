﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HUA.FAQ.Business.Modules;
using HUA.FAQ.Business.Modules.FAQ;
using HUA.FAQ.Entities;

namespace HUA.FAQ.Web.Controllers
{
    public class HomeController : BaseController
    {
        private readonly IModule<Entities.FAQ, FAQModel, FAQSearchModel> _module;
        public HomeController(IFaqContext context)
        {
            _module = new FAQModule(context);
        }
     

     

        public ActionResult Index()
        {
            
            ViewBag.faqs = ((FAQModule)_module).Firsts(3);
            ViewBag.tags = ((FAQModule)_module).tagModule.GetRamdom(5);

            ViewBag.SearchController = "FAQ";
            ViewBag.SearchAction = "List";
                
            return View();
        }
        
    }
}