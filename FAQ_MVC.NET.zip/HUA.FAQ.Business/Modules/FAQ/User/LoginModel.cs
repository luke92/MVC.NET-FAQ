﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace HUA.FAQ.Business.Modules.FAQ.User
{
    public class LoginModel : GenericModel
    {
        [Required(ErrorMessage = "El UserName es requerido")]
        [Index(IsUnique = true)]
        [StringLength(15, MinimumLength = 5, ErrorMessage = "El UserName debe tener entre 5 y 15 caracteres")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "El Password es requerido")]
        [Index(IsUnique = true)]
        [StringLength(15, MinimumLength = 5, ErrorMessage = "El Password debe tener entre 5 y 15 caracteres")]
        public string Password { get; set; }
    }
}
