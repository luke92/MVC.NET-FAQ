﻿using System;
using System.Collections.Generic;
using System.Text;
using HUA.FAQ.Business.Modules.FAQ;
using HUA.FAQ.Entities;

namespace HUA.FAQ.Business.Modules
{
    public interface IModule<TE,TM,in TS>
    {
        TE ToEntity(TM model);
        TM ToModel(TE entity);
        TM GetById(Guid id);
        IEnumerable<TM> GetAll();
        PaginableList<TM> GetPaginableList(TS searchModel);
        bool ExistModel(TM model);
        int Add(TM model);
        int Update(TM model);
        int Delete(TM model);
        int Delete(Guid id);
    }
}
