﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using HUA.FAQ.Business.Modules.FAQ;
using HUA.FAQ.Business.Modules.FAQ.User;

namespace HUA.FAQ.Web.Controllers
{
    public class LoginController : BaseController
    {

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login(LoginModel loginModel)
        {
            if (ModelState.IsValid)
            {
                if (!LoginModule.ExistModel(loginModel))
                {
                    ModelState.AddModelError("Error", "El usuario no se encuentra registrado");
                    return View("Index", loginModel);
                }
                else if (!LoginModule.ExistUser(loginModel))
                {
                    ModelState.AddModelError("Error", "La contraseña es incorrecta");
                    return View("Index", loginModel);
                }
                else
                {
                    FormsAuthentication.SetAuthCookie(loginModel.UserName, true);
                    return RedirectToAction("Index", "Home");
                }
            }

            return View("Index", loginModel);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(LoginModel userModel)
        {
            if (ModelState.IsValid)
            {
                if (LoginModule.ExistModel(userModel))
                {
                    ModelState.AddModelError("Error", "El UserName ya se encuentra registrado");
                    return View(userModel);
                }
                else
                {
                    LoginModule.Add(userModel);
                    return RedirectToAction("Index", "Home");
                }
            }

            return View(userModel);
        }
    }
}