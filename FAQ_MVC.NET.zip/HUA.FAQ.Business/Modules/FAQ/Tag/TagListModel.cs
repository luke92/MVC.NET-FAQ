﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HUA.FAQ.Business.Modules.FAQ.Tag
{
    public class TagListModel
    {
        public List<TagModel> Items { get; set; }

        public override string ToString()
        {
            string aux = "";
            foreach (var item in Items)
            {
                aux += item.Nombre + ", ";
            }

            return aux;
        }

        public TagListModel(List<TagModel> tagsModels)
        {
            Items = new List<TagModel>();
            Items.AddRange(tagsModels);
        }

        public TagListModel()
        {
            Items = new List<TagModel>();
        }
    }
}
