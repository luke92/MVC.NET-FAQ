﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace HUA.FAQ.Business.Modules.FAQ
{
    public abstract class SearchModel : ISearchModel
    {
        public Guid ModelID { get; set; }
        public int Page { get; set; }
        public int PageSize { get; set; }
        public bool AscendingSort { get; set; }

        protected SearchModel()
        {
            this.AscendingSort = false;
            this.PageSize = 5;
            this.Page = 1;
        }

        public int CurrentPage()
        {
            return this.Page;
        }

        int ISearchModel.PageSize()
        {
            return this.PageSize;
        }

        public int AddPages(int add)
        {
            this.Page += add;
            return this.Page;
        }

        public int SetPages(int page)
        {
            this.Page = page;
            return this.Page;
        }

        public ISearchModel NextPage()
        {
            ISearchModel copy = (ISearchModel)this.MemberwiseClone();
            copy.AddPages(1);
            return copy;
        }

        public ISearchModel PreviousPage()
        {
            ISearchModel copy = (ISearchModel) this.MemberwiseClone();
            copy.AddPages(-1);
            return copy;
        }

        public ISearchModel SaltPage(int page)
        {
            ISearchModel copy = (ISearchModel)this.MemberwiseClone();
            copy.SetPages(page);
            return copy;
        }
    }
}
