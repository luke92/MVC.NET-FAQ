﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using HUA.FAQ.Business.Modules.FAQ.Tipo;
using HUA.FAQ.Entities;

namespace HUA.FAQ.Business.Modules.FAQ
{
    public class TipoModule
    {
        private IFaqContext db;

        public TipoModule(IFaqContext _context)
        {
            db = _context;
        }
        public Entities.Tipo ToEntity(TipoModel tipoModel)
        {
            return new Entities.Tipo()
            {
                TipoID = tipoModel.Id,
                Nombre = tipoModel.Nombre
            };
        }

        public TipoModel ToModel(Entities.Tipo tipo)
        {
            return new TipoModel()
            {
                Id = tipo.TipoID,
                Nombre = tipo.Nombre
            };
        }

        public TipoModel Get(Guid ID)
        {
            if (ID == null) return null;
           
            return ToModel(db.Tipos.Find(ID));
        }

        public PaginableList<TipoModel> List(TipoSearchModel search)
        {
           
            var query = db.Tipos.AsQueryable();

            if (!String.IsNullOrEmpty(search.Nombre))
            {
                query = query.Where(x => x.Nombre.ToLower().Contains(search.Nombre.ToLower()));
            }

            IEnumerable<TipoModel> list = query.ToList().Select(x => ToModel(x));

            return new PaginableList<TipoModel>(list, search);
        }

        public int Add(TipoModel tipoModel)
        {
            db.Tipos.Add(ToEntity(tipoModel));
            return db.SaveChanges();
        }

        public int Add(string nombre)
        {

            return Add(new TipoModel()
            {
                Nombre = nombre
            });
        }

        public int Update(TipoModel tipoModel)
        {
            
            var tipoEntity = ToEntity(tipoModel);
            db.Tipos.Attach(tipoEntity);
            db.Entry(tipoEntity).State = EntityState.Modified;
            return db.SaveChanges();
        }

        public int Delete(TipoModel tipoModel)
        {
           
            db.Tipos.Remove(ToEntity(tipoModel));
            return db.SaveChanges();
        }

        public int Delete(Guid ID)
        {
           
            db.Tipos.Remove(db.Tipos.Find(ID));
            return db.SaveChanges();
        }

        public bool ExistModel(TipoModel tipoModel)
        {
            return db.Tipos.Any(t => t.Nombre.ToLower().Equals(tipoModel.Nombre.ToLower()));
        }
    }
}
