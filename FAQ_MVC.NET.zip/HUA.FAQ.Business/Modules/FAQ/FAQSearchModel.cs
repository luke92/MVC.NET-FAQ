﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HUA.FAQ.Business.Modules.FAQ
{
    public class FAQSearchModel : SearchModel
    {
        public String Solucion { get; set; }
        public String Nombre { get; set; }
        public String Descripcion { get; set; }
        public String Tag { get; set; }


        public FAQSearchModel() : base()
        {
            this.Nombre = "";
        }

        public FAQSearchModel(String nombre) : base()
        {
            this.Solucion = this.Nombre = this.Tag = this.Descripcion = nombre;
        }

        public override string ToString()
        {
            return this.Nombre;
        }
    }
}
