﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HUA.FAQ.Business.Modules.FAQ.Tag
{
    public class TagSearchModel : SearchModel
    {
        public String Nombre { get; set; }

        public TagSearchModel() : base()
        {
            this.Nombre = "";
        }

        public override string ToString()
        {
            return this.Nombre;
        }
    }
}
