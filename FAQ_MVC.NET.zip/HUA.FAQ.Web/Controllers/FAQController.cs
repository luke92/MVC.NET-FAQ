﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using HUA.FAQ.Business.Modules;
using HUA.FAQ.Business.Modules.FAQ;
using HUA.FAQ.Business.Modules.FAQ.Tag;
using HUA.FAQ.Business.Modules.FAQ.Tipo;
using HUA.FAQ.Entities;
using HUA.FAQ.Web.Models;
using HUA.FAQ.Web.Utils.FileStorageManagment;

namespace HUA.FAQ.Web.Controllers
{
    public class FAQController : BaseController
    {
        private readonly IModule<Entities.FAQ, FAQModel, FAQSearchModel> _module;

        private readonly IFileStorageProvider _fileStorageProvider;

        public FAQController(IFaqContext context, IFileStorageProvider fileStorageProvider)
        {
            _module = new FAQModule(context);
            _fileStorageProvider = fileStorageProvider;
        }

        public ActionResult Index()
        {
            //((FAQModule) _module)
            return RedirectToAction("List");
        }

        public ActionResult List(FAQSearchModel search)
        {
            search = search ?? new FAQSearchModel();

            search.Solucion = search.Tag = search.Descripcion = search.Nombre;
            PaginableList<FAQModel> list = _module.GetPaginableList(search);

            return View("List", list);
        }

        public ActionResult Create()
        {
            CargarDropDownLists();

            return View();
        }

       
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateInput(false)]
        public ActionResult Create(FAQModel faqModel)
        {
            if (!ModelState.IsValid)
            {
                CargarDropDownLists();
                return View(faqModel);
            }
            
            if (NoExistenDatosObligatorios(faqModel))
                {
                    CargarDropDownLists();
                    return View(faqModel);
                }
                if (_module.ExistModel(faqModel))
                {
                    ModelState.AddModelError("Error", "Esta Pregunta ya existe");
                    return View(faqModel);
                }
                else
                {

                    _module.Add(faqModel);
                    return RedirectToAction("Index");
                }
            
        }

        public JsonResult Autocomplete(string term)
        {
            string[] sugerencias = ((FAQModule)_module).GetSugerencias(term);

            return this.Json(sugerencias);

        }

        public ActionResult Details(Guid id)
        {
            if (id == Guid.Empty)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            FAQModel faqModel = _module.GetById(id);
            if (faqModel == null)
            {
                return HttpNotFound();
            }
            else
            {
                FAQListModel lista = new FAQListModel();
                lista.Items.AddRange(((FAQModule)_module).GetRelatedFaQs( id));
                faqModel.FaqsRelacionados = lista;
                ViewBag.MiLista = ((FAQModule)_module).tipoModule.List(new TipoSearchModel()).list.ToList();
            }
            return View(faqModel);
        }

        public ActionResult Edit(Guid id)
        {
            if (id == Guid.Empty)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            FAQModel faqModel = _module.GetById(id);
            if (faqModel == null)
            {
                return HttpNotFound();
            }

            CargarDropDownLists();

            return View(faqModel);
        }

        [ValidateInput(false)]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(FAQModel faqModel)
        {
            if (NoExistenDatosObligatorios(faqModel))
            {
                CargarDropDownLists();
                return View(faqModel);
            }
            _module.Update(faqModel);
            return RedirectToAction("Index");

        }

        public ActionResult FaqsByTag(TagSearchModel search)
        {
            if (search.ModelID == Guid.Empty)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            PaginableList<FAQModel> list = ((FAQModule)_module).GetRelatedFaqsByTag(search);

            return View("List", list);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Qualify(Guid id, int rating)
        {
            var respuesta = new JsonModel();
            if (id == Guid.Empty)
            {
                respuesta.Status = "error";
                respuesta.Message = "No se envío ID de FAQ!";
                return Json(respuesta);
            }
            FAQModel faqModel = _module.GetById(id);
            if (faqModel == null)
            {
                respuesta.Status = "error";
                respuesta.Message = "No se encontró FAQ con ese ID!";
                return Json(respuesta);
            }
            faqModel.CantidadVotos += 1;
            faqModel.Rating += rating;
            ((FAQModule)_module).Qualify(faqModel);

            respuesta.Status = "OK";
            respuesta.Message = "Gracias por calificar la pregunta!";
            return Json(respuesta);
        }

        private bool NoExistenDatosObligatorios(FAQModel faqModel)
        {
            return (faqModel.Nombre == null || faqModel.Solucion == null);
        }

        private void CargarDropDownLists()
        {
            List<TipoModel> tipos = ((FAQModule)_module).tipoModule.List(new TipoSearchModel()).list.ToList();
            ViewBag.Tipos = tipos;

            TagListModel tags = new TagListModel(((FAQModule)_module).tagModule.All().ToList());

            ViewBag.Tags = new MultiSelectList(tags.Items, "Id", "Nombre");
        }
    }
}