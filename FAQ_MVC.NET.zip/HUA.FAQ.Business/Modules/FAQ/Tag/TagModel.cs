﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace HUA.FAQ.Business.Modules.FAQ.Tag
{
    public class TagModel : GenericModel
    {
        [Required (ErrorMessage= "El nombre es requerido")]
        [Index(IsUnique = true)]
        [StringLength(50, MinimumLength = 3,ErrorMessage= "El nombre debe tener entre 3 y 50 caracteres")]
        public String Nombre { get; set; }

        public override string ToString()
        {
            return Nombre;
        }

        public TagModel()
        {
            Id = Guid.NewGuid();
        }
    }
}
