﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HUA.FAQ.Business.Modules;
using HUA.FAQ.Business.Modules.FAQ;
using HUA.FAQ.Business.Modules.FAQ.Tag;
using HUA.FAQ.Entities;

namespace HUA.FAQ.Web.Controllers
{
    public class TagController : BaseController
    {
        private TagModule tagModule;
        public TagController(IFaqContext context)
        {
            tagModule = new TagModule(context);
        }
        // GET: FAQ
        public ActionResult Index()
        {
            return RedirectToAction("List");
        }

        public ActionResult List(TagSearchModel search)
        {
            search = search ?? new TagSearchModel();

            PaginableList<TagModel> list = tagModule.List(search);

            return View("List", list);
        }

        public ActionResult Edit(Guid id)
        {
            if (id == Guid.Empty)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TagModel faqModel = tagModule.Get(id);
            if (faqModel == null)
            {
                return HttpNotFound();
            }
            return View(faqModel);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(TagModel tagModel)
        {
            if (ModelState.IsValid)
            {
                if (tagModule.ExistModel(tagModel))
                {
                    ModelState.AddModelError("Error", "Este tag ya existe");
                    return View(tagModel);
                }
                else
                {
                    tagModule.Add(tagModel);
                    return RedirectToAction("Index");
                }
            }

            return View(tagModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(TagModel tagModel)
        {
            if (ModelState.IsValid)
            {
                if (tagModule.ExistModel(tagModel))
                {
                    ModelState.AddModelError("Error", "Este tag ya existe");
                    return View(tagModel);
                }
                else
                {
                    tagModule.Update(tagModel);
                    return RedirectToAction("Index");
                }
            }
            return View(tagModel);
        }
    }
}