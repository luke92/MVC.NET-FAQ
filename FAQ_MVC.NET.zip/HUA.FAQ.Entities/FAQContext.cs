﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HUA.FAQ.Entities.Migrations;

namespace HUA.FAQ.Entities
{
    public class FaqContext : DbContext, IFaqContext
    {
        public FaqContext()
            : base("FAQ")
        {
        }

        public DbSet<FAQ> Faqs { get; set; }
        public virtual DbSet<Tag> Tags { get; set; }
        public virtual DbSet<Tipo> Tipos { get; set; }
        public virtual DbSet<User> Users { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<FaqContext, Configuration>());
            base.OnModelCreating(modelBuilder);

        }
    }
}
