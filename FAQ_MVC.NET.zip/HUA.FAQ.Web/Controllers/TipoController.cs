﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Http.ModelBinding;
using System.Web.Mvc;
using HUA.FAQ.Business.Modules;
using HUA.FAQ.Business.Modules.FAQ;
using HUA.FAQ.Business.Modules.FAQ.Tipo;
using HUA.FAQ.Entities;

namespace HUA.FAQ.Web.Controllers
{
    public class TipoController : BaseController
    {
        private TipoModule tipoModule;

        public TipoController(IFaqContext context)
        {
            tipoModule = new TipoModule(context);
        }
        // GET: FAQ
        public ActionResult Index()
        {
            return RedirectToAction("List");
        }

        public ActionResult List(TipoSearchModel search)
        {
            search = search ?? new TipoSearchModel();

            PaginableList<TipoModel> list = tipoModule.List(search);

            return View("List", list);
        }

        public ActionResult Edit(Guid id)
        {
            if (id == Guid.Empty)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TipoModel tipoModel = tipoModule.Get(id);
            if (tipoModel == null)
            {
                return HttpNotFound();
            }
            return View(tipoModel);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(TipoModel tipoModel)
        {
            if (ModelState.IsValid)
            {
                if (tipoModule.ExistModel(tipoModel))
                {
                    ModelState.AddModelError("Error", "Este Tipo de Pregunta ya existe");
                    return View(tipoModel);
                }
                else
                {
                    tipoModule.Add(tipoModel);
                    return RedirectToAction("Index");
                }
            }

            return View(tipoModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(TipoModel tipoModel)
        {
            if (ModelState.IsValid)
            {
                if (tipoModule.ExistModel(tipoModel))
                {
                    ModelState.AddModelError("Error", "Este Tipo de Pregunta ya existe");
                    return View(tipoModel);
                }
                else
                {
                    tipoModule.Update(tipoModel);
                    return RedirectToAction("Index");
                }
            }
            
            return View(tipoModel);

        }
    }
}